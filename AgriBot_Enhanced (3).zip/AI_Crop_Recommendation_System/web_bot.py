"""
web_bot.py
----------
WebBot = the original AgriBot brain (chatbot_engine.py) + new abilities:

  * Problem solver  - farmer describes a problem ("patte peele ho rahe hain",
                      "wheat has yellow rust", "پانی کھڑا ہو گیا") -> cause + solution + prevention
  * Fertilizer plan, sowing calendar, irrigation advice, soil-health report
  * Urdu / English replies, Urdu-script and Roman-Urdu keyword understanding
  * Rich messages (cards) for the web interface. The bot never shows option
    buttons - it simply answers whatever the farmer asks.

The Decision Tree and the step-by-step question flow are still the original ones.
"""

import re

import advisor
import chatbot_engine as ce
import model_utils as mu
from knowledge_base import CROP_EMOJI, CROP_UR, CROPS  # noqa: F401  (re-exported for app.py)

# Urdu (۰-۹) and Arabic-Indic (٠-٩) digits -> 0-9
DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")

# Urdu-script words -> the English/Roman-Urdu words the original engine understands.
ROMAN_MAP = {
    "السلام علیکم": "salam", "سلام": "salam", "ہیلو": "hello", "ہائے": "hi",
    "شکریہ": "shukriya", "مہربانی": "shukriya", "خدا حافظ": "bye", "اللہ حافظ": "bye",
    "مدد": "help", "آپ کیا کر سکتے ہیں": "what can you do",
    "شروع": "start", "فصل بتاؤ": "recommend crop", "فصل بتائیں": "recommend crop",
    "فصل بتائیے": "recommend crop", "فصل کی تجویز": "recommend crop", "فصل تجویز": "recommend crop",
    "تجویز": "recommend", "سفارش": "recommend",
    "ہاں": "haan", "جی": "ji", "جی ہاں": "haan", "نہیں": "nahi", "ٹھیک ہے": "theek",
    "معلوم نہیں": "nahi pata", "پتہ نہیں": "nahi pata", "پتا نہیں": "nahi pata",
    "منسوخ": "cancel", "کیوں": "why", "وجہ": "why", "متبادل": "alternatives", "دوسری فصلیں": "alternatives",
    "نائٹروجن": "nitrogen", "فاسفورس": "phosphorus", "پوٹاشیم": "potassium", "پوٹاش": "potassium",
    "درجہ حرارت": "temperature", "نمی": "humidity", "بارش": "rainfall",
    "گندم": "wheat", "چاول": "rice", "دھان": "rice", "مکئی": "maize", "کپاس": "cotton",
    "گنا": "sugarcane", "چنا": "chickpea", "مسور": "lentil", "آلو": "potato",
    "ٹماٹر": "tomato", "مونگ پھلی": "groundnut",
    "فصل": "crop", "کے بارے میں": "about", "بتاؤ": "tell", "بتائیں": "tell", "بتائیے": "tell",
    "کھاد": "fertilizer", "یوریا": "urea", "مشورہ": "advice",
    "بوائی": "sowing", "کاشت": "sowing", "کٹائی": "harvest", "کب": "when", "موسم": "season",
    "آبپاشی": "irrigation", "کتنا پانی": "how much water", "مٹی کی جانچ": "soil health",
    "مٹی کی صحت": "soil health", "پچھلی چیٹ": "previous chat",
}
ROMAN_KEYS = sorted(ROMAN_MAP, key=len, reverse=True)
_ROMAN_RE = re.compile(r"(?<!\w)(" + "|".join(re.escape(k) for k in ROMAN_KEYS) + r")(?!\w)")


def to_roman(text):
    t = text.translate(DIGITS)
    return _ROMAN_RE.sub(lambda m: f" {ROMAN_MAP[m.group(1)]} ", t)


FERT_WORDS = ["fertilizer", "fertiliser", "fertilizers", "khad", "khaad", "urea", "dap", "manure", "npk dose", "kitni khad"]
CAL_WORDS = ["when to sow", "when to plant", "when to grow", "sowing", "sowing time", "harvest", "harvesting", "calendar",
             "season", "kab boyen", "kab bona", "kab lagayen", "kab lagana", "time to sow", "best time"]
IRR_WORDS = ["irrigation", "how much water", "water requirement", "water need", "sinchai", "kitna pani", "kitna paani", "watering"]
SOIL_WORDS = ["soil health", "soil report", "check my soil", "soil status", "soil analysis", "mitti ki jaanch", "soil condition"]


class WebBot(ce.AgriBot):
    lang = "en"
    persist = True

    def __init__(self, history_file, trained, on_report=None, persist=True):
        super().__init__(history_file=history_file, trained=trained)
        self.lang = "en"
        self.on_report = on_report
        self.persist = persist          # guests: chats stay in memory only, never written to disk

    # ------------------------------------------------------------ helpers
    def T(self, en, ur):
        return ur if self.lang == "ur" else en

    def _save(self):
        if self.persist:
            super()._save()

    def _bot_x(self, text, **extra):
        return self._add("bot", text, extra or None)

    def _last_crop(self):
        return self.current["state"].get("last_prediction")

    # ------------------------------------------------------------ chat start
    def new_chat(self):
        replies = super().new_chat()
        if self.lang == "ur":
            replies[0]["text"] = "السلام علیکم! 👋 میں AgriBot ہوں، آپ کا فصل مشیر۔\nآج میں آپ کی کیسے مدد کر سکتا ہوں؟"
        self._save()
        return replies

    # --------------------------------------------------------- Urdu overrides
    def _question(self, feature):
        if self.lang != "ur":
            return super()._question(feature)
        i = mu.FEATURES.index(feature) + 1
        lo, hi = self.ranges[feature]
        fmt = (lambda x: f"{x:.1f}") if feature == "ph" else (lambda x: f"{x:.0f}")
        asks = {
            "N": "آپ کی مٹی میں نائٹروجن کتنی ہے؟ کلوگرام فی ہیکٹر میں لکھیں",
            "P": "آپ کی مٹی میں فاسفورس کتنا ہے؟ کلوگرام فی ہیکٹر میں لکھیں",
            "K": "آپ کی مٹی میں پوٹاشیم کتنا ہے؟ کلوگرام فی ہیکٹر میں لکھیں",
            "temperature": "آپ کے علاقے کا اوسط درجہ حرارت کتنا ہے؟ °C میں لکھیں",
            "humidity": "اوسط نمی (ہوا میں) کتنی ہے؟ فیصد میں لکھیں",
            "ph": "آپ کی مٹی کا pH کتنا ہے؟ 0 سے 14 کے درمیان عدد لکھیں",
            "rainfall": "آپ کے علاقے میں کتنی بارش ہوتی ہے؟ ملی میٹر میں لکھیں",
        }
        return (f"مرحلہ {i} / {len(mu.FEATURES)} - {advisor.feature_label(feature, 'ur')}\n"
                f"{asks[feature]} (عام حد: {fmt(lo)} سے {fmt(hi)})۔\n"
                "معلوم نہیں؟ بس \"معلوم نہیں\" لکھ دیں۔")

    def _begin_prediction(self, announce, question=None):
        replies = super()._begin_prediction(announce, question)
        if self.lang == "ur" and announce:
            replies[0]["text"] = (
                "بہت خوب، آئیے آپ کی زمین کے لیے سب سے موزوں فصل تلاش کرتے ہیں! 🌾 میں مٹی اور موسم کے بارے میں "
                "7 مختصر سوال ایک ایک کر کے پوچھوں گا۔\nمشورہ: آپ سب کچھ ایک ہی لائن میں بھی لکھ سکتے ہیں، جیسے:\n"
                "N=90 P=42 K=40 temp=26 humidity=82 ph=6.1 rainfall=210\n"
                "آپ کسی بھی وقت سوال پوچھ سکتے ہیں، یا روکنے کے لیے cancel لکھیں۔")
        return replies

    def _finish_prediction(self, prefix=""):
        replies = super()._finish_prediction(prefix)
        state = self.current["state"]
        report = advisor.build_report(self.model, self.profiles, state["last_values"], self.lang)
        lead, card, follow = replies
        if self.lang == "ur":
            lead["text"] = ((prefix + "\n\n" if prefix else "") +
                            "شکریہ! مجھے ساتوں قدریں مل گئی ہیں۔ یہ رہی میری تجویز:")
            follow["text"] = ("آپ \"کیوں\" پوچھ کر وجہ جان سکتے ہیں، یا \"متبادل\" لکھ کر دوسری اچھی فصلیں دیکھ سکتے ہیں۔ "
                              "بوائی سے پہلے مقامی ماہرِ زراعت سے تصدیق ضرور کر لیں۔")
        card["extra"]["report"] = report
        card["time"] = ce._now()
        if self.on_report:
            try:
                report["id"] = self.on_report(report)
                card["extra"]["report"] = report
            except Exception:
                pass
        return replies

    def _fmt_value(self, feature, value):
        if self.lang != "ur":
            return super()._fmt_value(feature, value)
        unit = mu.FEATURE_INFO[feature][1]
        return f"{advisor.feature_label(feature, 'ur').split(' (')[0]} = {value:g}" + (f" {unit}" if unit else "")

    def _prefix(self, accepted, errors):
        if self.lang != "ur":
            return super()._prefix(accepted, errors)
        lines = list(errors)
        if accepted:
            lines.append("✔ مل گیا: " + "، ".join(accepted))
        return "\n".join(lines)

    def _a_greeting(self, norm, toks):
        return self.T("Hello! How can I help you with your crops today?", "السلام علیکم! آج میں آپ کی فصل میں کیسے مدد کروں؟")

    def _a_thanks(self, norm, toks):
        return self.T("You're welcome! 🌱 Ask me anything else about your farm.", "خوش آمدید! 🌱 کاشت کاری سے متعلق کچھ اور پوچھنا ہو تو بتائیں۔")

    def _a_bye(self, norm, toks):
        return self.T("Goodbye! Happy farming 🌾", "خدا حافظ! خوشحال کاشت کاری 🌾")

    def _a_help(self, norm, toks):
        return self.T(
            "I can help you with:\n"
            "🌾 Crop recommendation from your soil & weather (Decision Tree AI)\n"
            "🐛 Crop problems - pests, diseases, yellow leaves, water & soil issues, with solutions\n"
            "🧪 Fertilizer plan (urea / DAP / potash) for your crop\n"
            "📅 Sowing & harvest time, 💧 irrigation advice, 🌱 soil health check\n"
            "ℹ️ Information about 10 crops\n"
            "Just type or speak - in English or Urdu (Roman Urdu works too).",
            "میں ان چیزوں میں مدد کر سکتا ہوں:\n"
            "🌾 آپ کی مٹی اور موسم کی بنیاد پر فصل کی تجویز (ڈیسیژن ٹری AI)\n"
            "🐛 فصل کے مسائل - کیڑے، بیماریاں، پیلے پتے، پانی اور زمین کی مشکلات، حل کے ساتھ\n"
            "🧪 آپ کی فصل کے لیے کھاد کا منصوبہ (یوریا / DAP / پوٹاش)\n"
            "📅 بوائی اور کٹائی کا وقت، 💧 آبپاشی کا مشورہ، 🌱 مٹی کی صحت کی جانچ\n"
            "ℹ️ 10 فصلوں کی معلومات\n"
            "بس لکھیں یا بولیں - اردو یا انگریزی میں (رومن اردو بھی چلے گی)۔")

    def _fallback(self, feature=None):
        if self.lang == "ur" and not feature:
            state = self.current["state"]
            state["fallback_n"] = state.get("fallback_n", 0) + 1
            return [self._bot_x("معذرت، میں سمجھ نہیں پایا۔ میں فصل کی تجویز، فصل کے مسائل کے حل، کھاد، بوائی کے وقت "
                                "اور آبپاشی میں مدد کر سکتا ہوں۔ براہِ کرم اپنی بات دوسرے الفاظ میں لکھیں۔")]
        return super()._fallback(feature)

    def _a_why(self, norm, toks):
        if self.lang != "ur":
            return super()._a_why(norm, toks)
        state = self.current["state"]
        if not state["last_prediction"]:
            return "میں نے اس چیٹ میں ابھی کوئی تجویز نہیں دی۔ \"شروع\" لکھیں، میں آپ کے لیے فصل تلاش کروں گا۔"
        crop, values = state["last_prediction"], state["last_values"]
        prof = self.profiles[crop]
        good, less = [], []
        for f in mu.FEATURES:
            lo, hi, _ = prof[f]
            (good if lo <= values[f] <= hi else less).append(advisor.feature_label(f, "ur"))
        text = f"میں نے {advisor.crop_name(crop, 'ur')} اس لیے تجویز کی کیونکہ آپ کے حالات اس کی عام ضرورت سے ملتے ہیں۔\n"
        if good:
            text += "• اچھا میل: " + "، ".join(good) + "\n"
        if less:
            text += "• کم میل: " + "، ".join(less) + "\n"
        return text + "فیصلہ کرنے سے پہلے مقامی ماہرِ زراعت سے بھی پوچھ لیں۔"

    def _a_alternatives(self, norm, toks):
        if self.lang != "ur":
            return super()._a_alternatives(norm, toks)
        state = self.current["state"]
        if not state["last_prediction"]:
            return "میں نے ابھی کوئی تجویز نہیں دی۔ \"شروع\" لکھیں۔"
        top = mu.predict_top(self.model, state["last_values"], k=3)
        lines = [f"  {i}. {advisor.crop_name(c, 'ur')} - {ce._pct(p)}" for i, (c, p) in enumerate(top, 1)]
        return "آپ کے حالات کے لیے سب سے اچھی فصلیں:\n" + "\n".join(lines) + "\n(فیصد بتاتا ہے کہ آپ کے حالات اس فصل سے کتنے ملتے ہیں۔)"

    # ------------------------------------------------------------------ handle
    def handle(self, text):
        text = (text or "").strip()
        if not text:
            return []
        self._add("user", text)
        try:
            roman = to_roman(text)
            replies = self._extended(text, roman) or self._route(roman)
        except Exception as exc:  # the chat must never crash
            replies = [self._bot(f"Sorry, something went wrong ({exc}). Please try again.")]
        self._save()
        return replies

    # ------------------------------------------------------ extended routing
    def _extended(self, original, roman):
        norm = ce._normalise(roman)
        toks = ce._tokens(norm)
        state = self.current["state"]
        if self._memory_intent(norm):
            return None
        if state["active"]:
            # let the original question flow handle answers to the pending question
            if (ce.parse_key_values(norm) or ce._is_numeric_message(norm) or self._is_affirm(toks)
                    or self._is_negative(toks) or any(ce._contains_phrase(norm, p) for p in ce.DONT_KNOW)
                    or any(ce._contains_phrase(norm, w) for w in ("cancel", "stop", "abort", "quit"))):
                return None
            if any(ce._contains_phrase(norm, p) for p in ce.HOW_TO_FIND) and not self._feature_in(toks):
                return None

        crop = ce.find_crop(toks)
        wait = state.pop("await_crop", None)
        if wait and crop and len(toks) <= 3:
            return self._topic_reply(wait, crop, original)

        # 1. farmer problem  -> cause + solution
        hits = advisor.match_problems(original + " " + roman, crop or self._last_crop())
        if hits and not self._asks_engine_question(norm, toks):
            return self._problem_reply(hits, crop, original)

        # 2. new features
        has = lambda words: any(ce._contains_phrase(norm, w) for w in words)
        if has(FERT_WORDS):
            return self._topic_reply("fertilizer", crop, original)
        if has(IRR_WORDS):
            return self._topic_reply("irrigation", crop, original)
        if has(SOIL_WORDS):
            return self._soil_reply(original)
        if has(CAL_WORDS):
            return self._topic_reply("calendar", crop, original)

        if crop and advisor.is_generic_problem(original + " " + roman):
            return self._crop_problems_reply(crop, original)

        intent = self._detect_intent(norm, toks)
        if intent == "crop_info" and crop:
            return self._crop_reply(crop, original)
        if intent is None and advisor.is_generic_problem(original + " " + roman):
            return self._ask_problem(original)
        return None

    def _asks_engine_question(self, norm, toks):
        """'why', 'show alternatives', 'what is nitrogen' must still go to the original engine."""
        return bool(self._feature_in(toks) and ("what" in toks or "explain" in toks) and
                    not ce._contains_phrase(norm, "deficiency"))

    def _with_reminder(self, replies):
        state = self.current["state"]
        if state["active"]:
            replies.append(self._bot(self.T("Now, back to your recommendation.\n\n", "اب واپس آپ کی تجویز کی طرف چلتے ہیں۔\n\n")
                                     + self._question(mu.FEATURES[state["step"]])))
        return replies

    # -- problem solver
    def _problem_text(self, card):
        steps = "\n".join(f"{i}. {s}" for i, s in enumerate(card["steps"], 1))
        prevent = "\n".join(f"• {s}" for s in card["prevent"])
        return (f"{card['title']}\n{self.T('Cause', 'وجہ')}: {card['cause']}\n\n"
                f"{self.T('What to do', 'حل')}:\n{steps}\n\n{self.T('Prevention', 'روک تھام')}:\n{prevent}\n\n{card['warning']}")

    def _problem_reply(self, hits, crop, original):
        crop = crop or self._last_crop()
        best = hits[0][0]
        card = advisor.problem_card(best, self.lang, crop)
        self._record_topic(self.T(f"Problem: {card['title']}", f"مسئلہ: {card['title']}"), original)
        if self.current["title"] == "New chat" or self.current["title"].startswith(("Problem", "مسئلہ")):
            self.current["title"] = self.T(f"Problem: {card['title']}", f"مسئلہ: {card['title']}")[:40]
        intro = self.T("I understand 🌿 this looks like **{t}**. Here is what you can do:",
                       "میں سمجھ گیا 🌿 یہ **{t}** لگ رہا ہے۔ آپ یہ کر سکتے ہیں:").format(t=card["title"])
        text = intro + "\n\n" + self._problem_text(card)
        if len(hits) > 1:
            others = [advisor.L(p["title"], self.lang) for p, _ in hits[1:]]
            text += "\n\n" + self.T("It could also be: ", "یہ بھی ہو سکتا ہے: ") + (", " if self.lang == "en" else "، ").join(others)
        msg = self._bot_x(text, problem=card)
        return self._with_reminder([msg])

    def _ask_problem(self, original):
        self._record_topic(self.T("Crop problem", "فصل کا مسئلہ"), original)
        msg = self._bot_x(self.T(
            "I'm sorry your crop is troubled 🌱 Tell me what you see - for example: the crop name and symptoms "
            "(\"wheat has yellow stripes on leaves\", \"tomato fruits cracking\", \"insects on cotton\").",
            "آپ کی فصل میں مسئلہ ہے، یہ جان کر افسوس ہوا 🌱 مجھے بتائیں آپ کو کیا نظر آ رہا ہے - فصل کا نام اور علامات "
            "(جیسے \"گندم کے پتوں پر پیلی دھاریاں\"، \"ٹماٹر کے پھل پھٹ رہے ہیں\"، \"کپاس میں کیڑے\")۔"))
        return self._with_reminder([msg])

    # -- crop based topics
    def _topic_reply(self, topic, crop, original):
        crop = crop or self._last_crop()
        state = self.current["state"]
        if not crop:
            state["await_crop"] = topic
            ask = {"fertilizer": ("Which crop do you want the fertilizer plan for?", "کس فصل کے لیے کھاد کا منصوبہ چاہیے؟"),
                   "calendar": ("Which crop do you want the sowing & harvest time for?", "کس فصل کی بوائی اور کٹائی کا وقت جاننا ہے؟"),
                   "irrigation": ("Which crop do you want irrigation advice for?", "کس فصل کے لیے آبپاشی کا مشورہ چاہیے؟")}[topic]
            return self._with_reminder([self._bot_x(self.T(*ask))])
        c = advisor.crop_card(crop, self.lang)
        name = f"{c['emoji']} {c['name']}"
        if topic == "fertilizer":
            values = state.get("last_values") if crop == state.get("last_prediction") else None
            plan = advisor.fertilizer_plan(crop, values, self.profiles[crop], self.lang)
            n = plan["nutrients"]
            text = (self.T(f"Fertilizer plan for {name}\nNutrient need: N {n['N']} - P₂O₅ {n['P']} - K₂O {n['K']} kg/ha\n"
                           f"≈ Urea {plan['urea']['acre']} kg + DAP {plan['dap']['acre']} kg + MOP {plan['mop']['acre']} kg per acre\n\n",
                           f"{name} کے لیے کھاد کا منصوبہ\nغذائی ضرورت: N {n['N']} - P₂O₅ {n['P']} - K₂O {n['K']} کلوگرام/ہیکٹر\n"
                           f"≈ فی ایکڑ یوریا {plan['urea']['acre']} کلو + DAP {plan['dap']['acre']} کلو + MOP {plan['mop']['acre']} کلو\n\n")
                    + "\n".join(f"{i}. {s}" for i, s in enumerate(plan["steps"], 1)) + "\n\n" + plan["note"])
            topic_label = self.T(f"Fertilizer plan ({crop})", f"کھاد کا منصوبہ ({c['name']})")
            extra = {"fertilizer": plan, "crop": c["name"]}
        elif topic == "calendar":
            text = self.T(f"{name} - sowing & harvest\n• Season: {c['season']}\n• Sowing: {c['sow']}\n• Harvest: {c['harvest']}\n• Duration: {c['duration']}",
                          f"{name} - بوائی اور کٹائی\n• موسم: {c['season']}\n• بوائی: {c['sow']}\n• کٹائی: {c['harvest']}\n• مدت: {c['duration']}")
            topic_label = self.T(f"Sowing calendar ({crop})", f"بوائی کا کیلنڈر ({c['name']})")
            extra = {}
        else:
            text = self.T(f"Irrigation for {name}\n{c['water']}", f"{name} کی آبپاشی\n{c['water']}")
            topic_label = self.T(f"Irrigation ({crop})", f"آبپاشی ({c['name']})")
            extra = {}
        self._record_topic(topic_label, original)
        return self._with_reminder([self._bot_x(text, **extra)])

    def _crop_reply(self, crop, original):
        c = advisor.crop_card(crop, self.lang, self.profiles[crop])
        rows = [f"• {i['label']}: {i['low']:g} - {i['high']:g} {i['unit']}".rstrip() for i in c["ideal"]]
        text = (self.T(f"{c['emoji']} {c['name']} is {ce.CROP_NOTES[crop]}\n• Season: {c['season']}\n• Sowing: {c['sow']}\n• Harvest: {c['harvest']}\n\n"
                       "Typical conditions (10th-90th percentile of the dataset):\n",
                       f"{c['emoji']} {c['name']} - {c['season']} کی فصل ہے۔\n• بوائی: {c['sow']}\n• کٹائی: {c['harvest']}\n\n"
                       "عام حالات (ڈیٹا سیٹ کا 10واں تا 90واں پرسنٹائل):\n") + "\n".join(rows))
        self._record_topic(self.T(f"Information about {crop}", f"{c['name']} کی معلومات"), original)
        return self._with_reminder([self._bot_x(text, crop_card=c)])

    def _soil_reply(self, original):
        state = self.current["state"]
        if not state.get("last_values"):
            return self._with_reminder([self._bot_x(self.T(
                "I need your soil values first. Say 'start' for a recommendation - then I will show a soil health check.",
                "پہلے مجھے آپ کی مٹی کی قدریں چاہییں۔ \"شروع\" لکھیں تاکہ تجویز شروع ہو - اس کے بعد میں مٹی کی صحت کی جانچ دکھاؤں گا۔"))])
        crop = state["last_prediction"]
        soil = advisor.soil_health(crop, state["last_values"], self.profiles[crop], self.lang)
        icon = {"ok": "✅", "low": "⬇️", "high": "⬆️"}
        lines = [f"{icon[r['status']]} {r['label']} = {r['value']:g} {r['unit']}".rstrip() + f" - {r['advice']}" for r in soil["rows"]]
        self._record_topic(self.T("Soil health check", "مٹی کی صحت کی جانچ"), original)
        head = self.T(f"Soil health for {advisor.crop_name(crop, 'en')}: {soil['score']}% of values are in the ideal range.",
                      f"{advisor.crop_name(crop, 'ur')} کے لیے مٹی کی صحت: {soil['score']}% قدریں مثالی حد میں ہیں۔")
        return [self._bot_x(head + "\n\n" + "\n".join(lines), soil=soil)]

    def _crop_problems_reply(self, crop, original):
        name = advisor.crop_name(crop, self.lang)
        self._record_topic(self.T(f"Common problems in {crop}", f"{name} کے عام مسائل"), original)
        titles = [p["title"] for p in advisor.crop_problems(crop, self.lang)]
        lines = "\n".join(f"{i}. {t}" for i, t in enumerate(titles, 1))
        text = self.T(f"Common problems in {name}:\n{lines}\n\nType the problem's name or describe what you see and I'll give you the solution.",
                      f"{name} کے عام مسائل:\n{lines}\n\nمسئلے کا نام لکھیں یا بتائیں کہ آپ کو کیا نظر آ رہا ہے، میں حل بتاؤں گا۔")
        return self._with_reminder([self._bot_x(text)])

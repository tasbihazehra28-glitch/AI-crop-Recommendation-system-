# AI Crop Recommendation System
# Algorithm: Decision Tree Classifier
# Run:  python train_model.py

import matplotlib
matplotlib.use("Agg")          # save the figure to a file (no window needed)
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.tree import export_text, plot_tree

import model_utils as mu

pd.set_option("display.width", 200)
pd.set_option("display.max_columns", None)

# 1-3. Load dataset, choose features/target, split 80% train / 20% test
X, y, data = mu.load_data()
X_train, X_test, y_train, y_test = mu.split_data(X, y)

print("=" * 60)
print("AI CROP RECOMMENDATION SYSTEM")
print("=" * 60)
print(f"Total records    : {len(data)}")
print(f"Crops            : {y.nunique()}  ({', '.join(sorted(y.unique()))})")
print(f"Training samples : {len(X_train)}")
print(f"Testing samples  : {len(X_test)}")

# 4. Hyper-parameter tuning (cross-validation on TRAINING data only)
print("\nTuning Decision Tree with GridSearchCV (5-fold CV)...")
search = mu.tune_model(X_train, y_train)
print("Best parameters found :", search.best_params_)
print(f"Best CV accuracy      : {search.best_score_ * 100:.2f}%")
print("Parameters used by the app (model_utils.BEST_PARAMS):", mu.BEST_PARAMS)

# 5. Train the final model
model = mu.build_model()
model.fit(X_train, y_train)

# 6. Test on unseen data
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print("\n" + "=" * 60)
print(f"Test Accuracy : {accuracy:.4f} ({accuracy * 100:.2f}%)")
print(f"Train Accuracy: {model.score(X_train, y_train) * 100:.2f}%")

print("\nClassification Report:")
print(classification_report(y_test, y_pred, zero_division=0))

print("Confusion Matrix (rows = actual, columns = predicted):")
print(pd.DataFrame(confusion_matrix(y_test, y_pred, labels=model.classes_),
                   index=model.classes_, columns=model.classes_))

# 7. Feature importance
importance = pd.Series(model.feature_importances_, index=X.columns)
print("\nFeature Importance:")
print(importance.sort_values(ascending=False).round(4))

# 8. Save results + tree picture
report = classification_report(y_test, y_pred, output_dict=True, zero_division=0)
pd.DataFrame({
    "Metric": ["Training samples", "Testing samples", "Accuracy",
               "Precision (macro)", "Recall (macro)", "F1-score (macro)"],
    "Value": [len(X_train), len(X_test), f"{accuracy * 100:.2f}%",
              f"{report['macro avg']['precision'] * 100:.2f}%",
              f"{report['macro avg']['recall'] * 100:.2f}%",
              f"{report['macro avg']['f1-score'] * 100:.2f}%"],
}).to_csv(mu.os.path.join(mu.BASE_DIR, "results_summary.csv"), index=False)

plt.figure(figsize=(24, 12))
plot_tree(model, feature_names=list(X.columns), class_names=list(model.classes_),
          filled=True, rounded=True, fontsize=6, max_depth=4)
plt.title("Decision Tree - Crop Recommendation (top 4 levels shown)")
plt.tight_layout()
plt.savefig(mu.os.path.join(mu.BASE_DIR, "decision_tree.png"), dpi=150)
plt.close()
print("\nSaved: decision_tree.png and results_summary.csv")

# 9. Example prediction
sample = {"N": 90, "P": 42, "K": 40, "temperature": 26,
          "humidity": 82, "ph": 6.1, "rainfall": 210}
top = mu.predict_top(model, sample, k=3)
print("\nExample Input:", sample)
print(f"Recommended Crop: {top[0][0].upper()}")
print("Top 3:", ", ".join(f"{c} ({p * 100:.0f}%)" for c, p in top))

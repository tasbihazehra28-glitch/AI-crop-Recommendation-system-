/* AgriBot web interface - plain JavaScript, no external libraries (works offline). */
(() => {
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
let lang = localStorage.getItem('agri_lang');
if (lang !== 'ur') lang = 'en';
let user = null, view = 'chat', busy = false, CROPS = [], recognizing = null;

/* ---------------------------------------------------------------- texts */
const STR = {
en: {
  tagline:'AI Crop Recommendation Assistant', nav_chat:'Chat', nav_recommend:'Recommend',
  new_chat:'New chat', recent:'Recent chats', type_msg:'Type or speak your question…', sign_in:'Sign in',
  guest_note:'👤 You are chatting as a guest, so your chats are not saved. Sign in to keep your chats.',
  rec_title:'🌱 Crop Recommendation', rec_sub:'Enter your soil and weather values. Leave a box empty if you don\'t know it - AgriBot will use a typical value.',
  rec_go:'Recommend crop', rec_example:'Try example', rec_clear:'Clear', rec_hint:'Tip: soil values come from a soil-test report; weather values from a weather app or local office.',
  my_reports:'📄 My reports', no_reports:'No saved reports yet. Your recommendations will appear here.',
  sowing:'Sowing', harvest:'Harvest', duration:'Duration', water:'Water',
  recommended:'Recommended crop', match:'match', top3:'Top 3 crops', soil_check:'Soil & climate check', factor:'Factor', value:'Value', range:'Ideal range', advice:'Advice',
  fert_plan:'Fertilizer plan (per acre)', urea:'Urea', cal:'Sowing & growing', rules:'How the Decision Tree decided', print:'🖨 Print / PDF report',
  cause:'Cause', solution:'What to do', prevention:'Prevention', assumed:'Typical values were used for', view:'View', delete:'Delete', confirm_del:'Delete this?',
  sign_title:'Welcome to AgriBot', sign_sub:'Sign in to save your chats and reports. Any name and password works - a new name creates your account automatically.',
  tab_in:'Sign in', tab_up:'Create account', name:'Your name', username:'Username or email', password:'Password', do_in:'Sign in', do_up:'Create account',
  err_missing:'Please enter your name/email and a password.', err_cred:'Could not sign in. Please try again.',
  hello:'Hello', logout:'Sign out', signed_in_as:'Signed in as', no_voice:'Voice input is not supported in this browser (use Chrome).', listening:'Listening…',
  bad_value:'Allowed range', num_only:'Enter a number', welcome_back:'Welcome', server_err:'Could not reach the server. Please try again.',
},
ur: {
  tagline:'مصنوعی ذہانت پر مبنی فصل کی تجویز کا مددگار', nav_chat:'چیٹ', nav_recommend:'تجویز',
  new_chat:'نئی چیٹ', recent:'حالیہ چیٹس', type_msg:'اپنا سوال لکھیں یا بولیں…', sign_in:'سائن اِن',
  guest_note:'👤 آپ مہمان کے طور پر چیٹ کر رہے ہیں، اس لیے آپ کی چیٹس محفوظ نہیں ہوں گی۔ چیٹس محفوظ رکھنے کے لیے سائن اِن کریں۔',
  rec_title:'🌱 فصل کی تجویز', rec_sub:'اپنی مٹی اور موسم کی قدریں لکھیں۔ جو قدر معلوم نہ ہو اسے خالی چھوڑ دیں - AgriBot عام قدر استعمال کرے گا۔',
  rec_go:'فصل تجویز کریں', rec_example:'مثال بھریں', rec_clear:'صاف کریں', rec_hint:'مشورہ: مٹی کی قدریں مٹی کے ٹیسٹ کی رپورٹ سے اور موسم کی قدریں موسم کی ایپ یا مقامی دفتر سے ملتی ہیں۔',
  my_reports:'📄 میری رپورٹس', no_reports:'ابھی کوئی رپورٹ محفوظ نہیں۔ آپ کی تجاویز یہاں نظر آئیں گی۔',
  sowing:'بوائی', harvest:'کٹائی', duration:'مدت', water:'پانی',
  recommended:'تجویز کردہ فصل', match:'میل', top3:'بہترین 3 فصلیں', soil_check:'مٹی اور موسم کی جانچ', factor:'عنصر', value:'قدر', range:'مثالی حد', advice:'مشورہ',
  fert_plan:'کھاد کا منصوبہ (فی ایکڑ)', urea:'یوریا', cal:'بوائی اور دیکھ بھال', rules:'ڈیسیژن ٹری نے کیسے فیصلہ کیا', print:'🖨 پرنٹ / PDF رپورٹ',
  cause:'وجہ', solution:'حل', prevention:'روک تھام', assumed:'ان کے لیے عام قدریں استعمال ہوئیں', view:'دیکھیں', delete:'حذف کریں', confirm_del:'کیا اسے حذف کریں؟',
  sign_title:'AgriBot میں خوش آمدید', sign_sub:'چیٹس اور رپورٹس محفوظ رکھنے کے لیے سائن اِن کریں۔ کوئی بھی نام اور پاس ورڈ چلے گا - نیا نام ہو تو آپ کا اکاؤنٹ خود بخود بن جائے گا۔',
  tab_in:'سائن اِن', tab_up:'اکاؤنٹ بنائیں', name:'آپ کا نام', username:'یوزر نیم یا ای میل', password:'پاس ورڈ', do_in:'سائن اِن کریں', do_up:'اکاؤنٹ بنائیں',
  err_missing:'براہِ کرم نام/ای میل اور پاس ورڈ لکھیں۔', err_cred:'سائن اِن نہیں ہو سکا۔ دوبارہ کوشش کریں۔',
  hello:'السلام علیکم', logout:'سائن آؤٹ', signed_in_as:'سائن اِن:', no_voice:'اس براؤزر میں وائس ان پٹ دستیاب نہیں (Chrome استعمال کریں)۔', listening:'سن رہا ہوں…',
  bad_value:'قابلِ قبول حد', num_only:'عدد لکھیں', welcome_back:'خوش آمدید', server_err:'سرور سے رابطہ نہیں ہو سکا۔ براہِ کرم دوبارہ کوشش کریں۔',
}};
const t = k => (STR[lang][k] ?? STR.en[k] ?? k);
const FEAT = {N:['Nitrogen (N)','نائٹروجن (N)'],P:['Phosphorus (P)','فاسفورس (P)'],K:['Potassium (K)','پوٹاشیم (K)'],
  temperature:['Temperature','درجہ حرارت'],humidity:['Humidity','نمی (ہوا میں)'],ph:['Soil pH','مٹی کا pH'],rainfall:['Rainfall','بارش']};
const fl = f => FEAT[f][lang === 'ur' ? 1 : 0];
const FIELDS = [
  {k:'N',unit:'kg/ha',min:0,max:300,ex:90, help:['From soil-test report','مٹی کے ٹیسٹ کی رپورٹ سے']},
  {k:'P',unit:'kg/ha',min:0,max:300,ex:42, help:['From soil-test report','مٹی کے ٹیسٹ کی رپورٹ سے']},
  {k:'K',unit:'kg/ha',min:0,max:300,ex:40, help:['From soil-test report','مٹی کے ٹیسٹ کی رپورٹ سے']},
  {k:'temperature',unit:'°C',min:-10,max:60,ex:26, help:['Average of growing season','فصل کے موسم کا اوسط']},
  {k:'humidity',unit:'%',min:0,max:100,ex:82, help:['Average relative humidity','اوسط نمی']},
  {k:'ph',unit:'',min:0,max:14,ex:6.1, help:['0-14, most crops like 6-7.5','0-14، زیادہ تر فصلوں کو 6-7.5 پسند ہے']},
  {k:'rainfall',unit:'mm',min:0,max:5000,ex:210, help:['Typical rainfall of your area','آپ کے علاقے کی عام بارش']},
];

/* -------------------------------------------------------------- helpers */
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt = s => esc(s).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/\n/g, '<br>');
const sleep = ms => new Promise(r => setTimeout(r, ms));
const pct = p => Math.round(p * 100) + '%';
function toast(msg){ const el = $('#toast'); el.textContent = msg; el.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove('show'), 2600); }
async function api(path, body){
  const opt = body !== undefined ? {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({lang, ...body})} : {};
  const url = body === undefined ? path + (path.includes('?') ? '&' : '?') + 'lang=' + lang : path;
  const r = await fetch(url, opt); const j = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(j.error || 'error'); e.data = j; e.status = r.status; throw e; }
  return j;
}
const cropInfo = c => CROPS.find(x => x.crop === c) || {name:c, emoji:'🌱'};

/* Urdu text must read right-to-left: let the browser pick the direction of every text block. */
const DIR_TAGS = 'div,li,td,th,p,h2,h3,h4,small,summary,label';
function setDir(el){
  if (!el || !el.matches || !el.matches(DIR_TAGS)) return;
  const leaf = ![...el.children].some(c => !['B','BR','I','CODE'].includes(c.tagName));
  if (leaf) el.setAttribute('dir', 'auto');
}
function autoDir(root){ if (root.querySelectorAll) { setDir(root); root.querySelectorAll(DIR_TAGS).forEach(setDir); } }
new MutationObserver(list => list.forEach(m => m.addedNodes.forEach(n => autoDir(n.nodeType === 1 ? n : n.parentElement || document.body))))
  .observe(document.body, {childList:true, subtree:true});

function applyI18n(){
  document.documentElement.lang = lang;
  document.body.classList.toggle('ur', lang === 'ur');
  $$('[data-i]').forEach(el => el.textContent = t(el.dataset.i));
  $$('[data-ph]').forEach(el => el.placeholder = t(el.dataset.ph));
  $$('#langSeg button').forEach(b => b.classList.toggle('active', b.dataset.lang === lang));
  renderUserBtn();
  $('#guestNote').textContent = t('guest_note');
  $('#guestNote').classList.toggle('show', !user);
  $('.side-title').style.display = user ? '' : 'none';
}

/* ----------------------------------------------------------------- views */
function show(v){
  view = v; document.body.dataset.view = v;
  $$('.view').forEach(x => x.classList.toggle('active', x.id === 'view-' + v));
  $$('#tabs button').forEach(b => b.classList.toggle('active', b.dataset.view === v));
  closeSidebar();
  if (v === 'recommend') loadReports();
  if (v === 'chat') scrollDown();
}
$('#tabs').addEventListener('click', e => { const b = e.target.closest('button'); if (b) show(b.dataset.view); });
const closeSidebar = () => { $('#sidebar').classList.remove('open'); $('#scrim').classList.remove('show'); };
$('#menuBtn').onclick = () => { $('#sidebar').classList.toggle('open'); $('#scrim').classList.toggle('show'); };
$('#scrim').onclick = closeSidebar;

/* ------------------------------------------------------------------ chat */
const msgBox = $('#messages');
const scrollDown = () => requestAnimationFrame(() => { msgBox.scrollTop = msgBox.scrollHeight; });
const hhmm = iso => { try { return new Date(iso).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'}); } catch { return ''; } };

function problemCard(p){
  return `<div class="card"><span class="cat">${esc(p.category)}</span>${p.crop ? ` <span class="cat">${esc(p.crop)}</span>` : ''}
    <h4>${esc(p.title)}</h4>
    <div class="cause"><b>${t('cause')}:</b> ${esc(p.cause)}</div>
    <b>✅ ${t('solution')}</b><ol class="steps">${p.steps.map(s => `<li>${esc(s)}</li>`).join('')}</ol>
    <div class="prevent"><b>🛡 ${t('prevention')}</b><ul>${p.prevent.map(s => `<li>${esc(s)}</li>`).join('')}</ul></div>
    <div class="warn">${esc(p.warning)}</div></div>`;
}

function fertTiles(f){
  return `<div class="fert"><div><b>${f.urea.acre} kg</b><span>${t('urea')}</span></div><div><b>${f.dap.acre} kg</b><span>DAP</span></div><div><b>${f.mop.acre} kg</b><span>MOP</span></div></div>`;
}

function reportCard(r){
  const assumed = r.assumed && r.assumed.length ? `<div class="warn">ℹ ${t('assumed')}: ${esc(r.assumed.join(lang === 'ur' ? '، ' : ', '))}</div>` : '';
  return `<div class="card">
   <div class="hero"><div class="e">${r.emoji}</div><div><small>${t('recommended')}</small><h3>${esc(r.name)}</h3><small>${esc(r.info.season)}</small></div>
     <div class="conf"><b>${pct(r.confidence)}</b><small>${t('match')}</small></div></div>
   <div class="sec-title">🏆 ${t('top3')}</div>
   <div class="top3">${r.top3.map(x => `<div class="r"><span>${x.emoji} ${esc(x.name)}</span><div class="bar"><i style="width:${Math.round(x.p*100)}%"></i></div><b>${pct(x.p)}</b></div>`).join('')}</div>
   <div class="sec-title">🌱 ${t('soil_check')} <span class="tag ${r.soil.score >= 70 ? 'ok' : 'low'}">${r.soil.score}%</span></div>
   <div class="scroll-x"><table class="t"><tr><th>${t('factor')}</th><th>${t('value')}</th><th>${t('range')}</th><th>${t('advice')}</th></tr>
   ${r.soil.rows.map(x => `<tr><td>${esc(x.label)}</td><td><span class="tag ${x.status}">${x.value} ${esc(x.unit)}</span></td><td>${x.low}-${x.high}</td><td>${esc(x.advice)}</td></tr>`).join('')}</table></div>
   <div class="sec-title">🧪 ${t('fert_plan')}</div>${fertTiles(r.fertilizer)}
   <ol class="steps">${r.fertilizer.steps.map(s => `<li>${esc(s)}</li>`).join('')}</ol><div class="hint" style="font-size:12px;color:var(--mu)">${esc(r.fertilizer.note)}</div>
   <div class="sec-title">📅 ${t('cal')}</div>
   <div class="kv"><div><b>${t('sowing')}</b>${esc(r.info.sow)}</div><div><b>${t('harvest')}</b>${esc(r.info.harvest)}</div><div><b>${t('duration')}</b>${esc(r.info.duration)}</div></div>
   <div class="kv"><div style="grid-column:1/-1"><b>💧 ${t('water')}</b>${esc(r.info.water)}</div></div>
   <ul class="steps" style="list-style:'🌿 ';padding-inline-start:22px">${r.info.tips.map(s => `<li>${esc(s)}</li>`).join('')}</ul>
   <details><summary>🌳 ${t('rules')}</summary><ul class="steps">${r.rules.map(s => `<li><code>${esc(s)}</code></li>`).join('')}</ul></details>
   ${assumed}
   <div class="btn-row">${r.id ? `<a class="ghost" style="text-decoration:none" target="_blank" href="/report/${r.id}?lang=${lang}">${t('print')}</a>` : ''}</div>
   <div class="warn">${esc(r.disclaimer)}</div></div>`;
}

function renderMsg(m){
  const x = m.extra || {}, user = m.sender === 'user';
  const row = document.createElement('div'); row.className = 'msg ' + (user ? 'user' : 'bot');
  let body = '';
  if (m.sender === 'card' && x.report) {
    body = reportCard(x.report);
  } else if (x.problem) {
    const parts = m.text.split('\n\n');
    const last = parts[parts.length - 1];
    const also = parts.length > 1 && /^(It could also be|یہ بھی ہو سکتا ہے)/.test(last) ? last : '';
    body = `<div>${fmt(parts[0])}</div>${problemCard(x.problem)}${also ? `<div style="margin-top:8px"><small>${esc(also)}</small></div>` : ''}`;
  } else if (m.sender === 'card') {
    body = `<div>${esc(m.text)}</div>`;
  } else {
    body = `<div>${fmt(m.text)}</div>`;
    if (x.fertilizer) body += fertTiles(x.fertilizer);
  }
  const tools = user ? '' : `<div class="tools"><button data-speak="1" title="Listen">🔊</button></div>`;
  row.innerHTML = (user ? '' : '<div class="avatar">🌾</div>') + `<div class="bubble">${body}${tools}${m.time ? `<span class="time">${hhmm(m.time)}</span>` : ''}</div>`;
  row._text = m.text;
  msgBox.appendChild(row);
  return row;
}
function typing(on){
  $('#typingRow')?.remove();
  if (!on) return;
  const row = document.createElement('div'); row.className = 'msg bot'; row.id = 'typingRow';
  row.innerHTML = '<div class="avatar">🌾</div><div class="bubble"><span class="typing"><i></i><i></i><i></i></span></div>';
  msgBox.appendChild(row); scrollDown();
}
function setMessages(list){
  msgBox.innerHTML = '';
  list.forEach(m => renderMsg(m));
  scrollDown();
}
function setChats(chats, title){
  const box = $('#chatList'); box.innerHTML = '';
  chats.forEach(c => {
    const el = document.createElement('button'); el.className = 'chat-item' + (c.current ? ' current' : '');
    const d = new Date(c.updated);
    el.innerHTML = `<span>💬</span><span class="t">${esc(c.title)}<br><span class="d">${d.toLocaleDateString([], {day:'numeric', month:'short'})} · ${hhmm(c.updated)}</span></span><span class="x" data-del="${c.id}" title="${t('delete')}">✕</span>`;
    el.onclick = async e => {
      if (e.target.dataset.del) { if (confirm(t('confirm_del'))) { const j = await api('/api/delete_chat', {id:c.id}); setMessages(j.messages); setChats(j.chats, j.title); } return; }
      const j = await api('/api/open_chat', {id:c.id}); setMessages(j.messages); setChats(j.chats, j.title); closeSidebar(); show('chat');
    };
    box.appendChild(el);
  });
  if (title) $('#chatTitle').textContent = title;
}

async function send(text){
  text = (text || '').trim(); if (!text || busy) return;
  busy = true; show('chat');
  renderMsg({sender:'user', text, time:new Date().toISOString()});
  typing(true);
  try {
    const j = await api('/api/chat', {message:text});
    for (let i = 0; i < j.replies.length; i++) {
      await sleep(i === 0 ? 350 : 650); typing(false);
      renderMsg(j.replies[i]); scrollDown();
      if (i < j.replies.length - 1) typing(true);
    }
    setChats(j.chats, j.title);
  } catch (e) { typing(false); renderMsg({sender:'bot', text:'⚠ ' + t('server_err')}); }
  busy = false; scrollDown();
}
msgBox.addEventListener('click', e => {
  if (e.target.closest('[data-speak]')) speak(e.target.closest('.msg')._text);
});
const input = $('#input');
input.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); const v = input.value; input.value = ''; autosize(); send(v); } });
input.addEventListener('input', autosize);
function autosize(){ input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 120) + 'px'; }
$('#sendBtn').onclick = () => { const v = input.value; input.value = ''; autosize(); send(v); };
$('#newChat').onclick = async () => { const j = await api('/api/new_chat', {}); setMessages(j.messages); setChats(j.chats, j.title); closeSidebar(); show('chat'); };

/* voice */
const voiceLang = () => lang === 'ur' ? 'ur-PK' : 'en-IN';
function speak(text){
  if (!('speechSynthesis' in window)) return toast(t('no_voice'));
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(String(text).replace(/\*\*/g, '').replace(/[•✔✅🌾🐛🌿]/g, ''));
  u.lang = voiceLang(); speechSynthesis.speak(u);
}
function listen(btn, target, done){
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) return toast(t('no_voice'));
  if (recognizing) { recognizing.stop(); return; }
  const r = new SR(); r.lang = voiceLang(); r.interimResults = true;
  r.onresult = e => { target.value = [...e.results].map(x => x[0].transcript).join(' '); autosize(); };
  r.onend = () => { btn.classList.remove('rec'); recognizing = null; if (done && target.value.trim()) done(); };
  r.onerror = () => { btn.classList.remove('rec'); recognizing = null; };
  recognizing = r; btn.classList.add('rec'); toast(t('listening')); r.start();
}
$('#micBtn').onclick = () => listen($('#micBtn'), input, () => { const v = input.value; input.value = ''; autosize(); send(v); });

/* ---------------------------------------------------------- recommend form */
function buildForm(){
  const keep = {}; $$('#recFields input').forEach(i => keep[i.name] = i.value);
  $('#recFields').innerHTML = FIELDS.map(f => `<div class="field"><label>${fl(f.k)} <small>${f.unit} · ${f.min}-${f.max}</small></label>
    <input type="number" inputmode="decimal" step="any" name="${f.k}" min="${f.min}" max="${f.max}" placeholder="${f.ex}" value="${keep[f.k] ?? ''}">
    <div class="help">${f.help[lang === 'ur' ? 1 : 0]}</div><div class="err"></div></div>`).join('');
}
$('#recExample').onclick = () => FIELDS.forEach(f => $(`#recFields input[name=${f.k}]`).value = f.ex);
$('#recClear').onclick = () => { $$('#recFields input').forEach(i => { i.value = ''; i.classList.remove('bad'); }); $$('#recFields .err').forEach(e => e.textContent = ''); $('#recResult').innerHTML = ''; };
$('#recGo').onclick = async () => {
  const values = {}; let ok = true;
  FIELDS.forEach(f => {
    const el = $(`#recFields input[name=${f.k}]`), err = el.nextElementSibling.nextElementSibling; err.textContent = ''; el.classList.remove('bad');
    const raw = el.value.trim(); if (raw === '') return;
    const v = Number(raw);
    if (!isFinite(v)) { err.textContent = t('num_only'); el.classList.add('bad'); ok = false; }
    else if (v < f.min || v > f.max) { err.textContent = `${t('bad_value')}: ${f.min}-${f.max}`; el.classList.add('bad'); ok = false; }
    else values[f.k] = v;
  });
  if (!ok) return;
  if (!Object.keys(values).length) { toast(t('rec_sub')); return; }
  try {
    const j = await api('/api/recommend', {values});
    $('#recResult').innerHTML = `<div style="margin-top:16px">${reportCard(j.report)}</div>`;
    $('#recResult').scrollIntoView({behavior:'smooth', block:'start'});
    loadReports();
  } catch (e) { toast('⚠ ' + (e.data?.error || e.message)); }
};
async function loadReports(){
  const box = $('#reportList');
  try {
    const j = await api('/api/reports');
    if (!j.reports.length) { box.innerHTML = `<div class="empty">${t('no_reports')}</div>`; return; }
    box.innerHTML = j.reports.map(r => { const c = cropInfo(r.crop); return `<div class="rep"><span class="e">${c.emoji}</span>
      <div class="m"><b>${esc(c.name)}</b> · ${pct(r.confidence)}<br><small>${new Date(r.created).toLocaleString([], {day:'numeric', month:'short', hour:'2-digit', minute:'2-digit'})}</small></div>
      <button class="ghost" data-rv="${r.id}">${t('view')}</button><button class="ghost" data-rd="${r.id}">✕</button></div>`; }).join('');
  } catch { box.innerHTML = ''; }
}
$('#reportList').addEventListener('click', async e => {
  const v = e.target.closest('[data-rv]'), d = e.target.closest('[data-rd]');
  if (v) { const j = await api('/api/report/' + v.dataset.rv); $('#recResult').innerHTML = `<div style="margin-top:16px">${reportCard(j.report)}</div>`; $('#recResult').scrollIntoView({behavior:'smooth'}); }
  if (d && confirm(t('confirm_del'))) { await api(`/api/report/${d.dataset.rd}/delete`, {}); loadReports(); }
});

/* ------------------------------------------------------------------- crops (names + icons for the report list) */
async function loadCrops(){
  const j = await api('/api/crops'); CROPS = j.crops;
}

/* ------------------------------------------------------------ modal + auth */
function openModal(html){ $('#modalCard').innerHTML = html; $('#modal').classList.add('show'); }
function closeModal(){ $('#modal').classList.remove('show'); }
$('#modal').addEventListener('click', e => {
  if (e.target.id === 'modal' || e.target.closest('[data-close]')) closeModal();
});
function renderUserBtn(){ $('#userBtn').textContent = user ? '👤 ' + user.name : '👤 ' + t('sign_in'); }
$('#userBtn').onclick = () => user ? userMenu() : authModal();
function userMenu(){
  openModal(`<button class="close" data-close="1">✕</button><h3>${t('hello')}, ${esc(user.name)} 👋</h3><p class="sub">${t('signed_in_as')} <b>${esc(user.username)}</b></p>
   <div class="btn-row"><button class="ghost" id="goReports">${t('my_reports')}</button><button class="ghost" id="doLogout">${t('logout')}</button></div>`);
  $('#goReports').onclick = () => { closeModal(); show('recommend'); };
  $('#doLogout').onclick = async () => { await api('/api/logout', {}); user = null; closeModal(); await boot(true, true); };
}
function authModal(mode = 'in'){
  const up = mode === 'up';
  const keepU = $('#aUser')?.value || '';
  openModal(`<button class="close" data-close="1">✕</button><h3>🌾 ${t('sign_title')}</h3><p class="sub">${t('sign_sub')}</p>
   <div class="auth-tabs"><button data-m="in" class="${up ? '' : 'active'}">${t('tab_in')}</button><button data-m="up" class="${up ? 'active' : ''}">${t('tab_up')}</button></div>
   <div class="auth-form">${up ? `<input id="aName" dir="auto" placeholder="${t('name')}" autocomplete="name">` : ''}
   <input id="aUser" dir="auto" placeholder="${t('username')}" autocomplete="username" autocapitalize="none" value="${esc(keepU)}"><input id="aPass" dir="auto" type="password" placeholder="${t('password')}" autocomplete="${up ? 'new-password' : 'current-password'}">
   <div class="auth-err" id="aErr"></div><button class="primary" id="aGo">${up ? t('do_up') : t('do_in')}</button></div>`);
  $$('.auth-tabs button').forEach(b => b.onclick = () => authModal(b.dataset.m));
  const go = async () => {
    const username = $('#aUser').value.trim(), password = $('#aPass').value;
    if (!username || !password) { $('#aErr').textContent = t('err_missing'); return; }
    try {
      const j = await api(up ? '/api/register' : '/api/login', {name:$('#aName')?.value, username, password});
      user = j.user; closeModal(); toast(`${t('welcome_back')}, ${user.name} 👋`); await boot(true);
    } catch (e) { $('#aErr').textContent = t(e.message === 'missing' ? 'err_missing' : 'err_cred'); }
  };
  $('#aGo').onclick = go;
  $$('#modalCard input').forEach(i => i.addEventListener('keydown', e => { if (e.key === 'Enter') go(); }));
  ($('#aUser').value ? $('#aPass') : $('#aUser')).focus();
}

/* -------------------------------------------------------------------- boot */
async function boot(reloadChat = true, fresh = false){
  applyI18n();
  const j = await api('/api/init', {fresh});
  user = j.user; applyI18n();
  if (reloadChat) { setMessages(j.messages); }
  setChats(j.chats, j.title);
}
$('#langSeg').addEventListener('click', async e => {
  const b = e.target.closest('button'); if (!b || b.dataset.lang === lang) return;
  lang = b.dataset.lang; localStorage.setItem('agri_lang', lang); applyI18n(); buildForm();
  await loadCrops();
  const j = await api('/api/init', {}); setChats(j.chats, j.title);
  if (view === 'recommend') loadReports();
  $('#recResult').innerHTML = '';
});
(async function start(){
  document.body.dataset.view = 'chat';
  buildForm(); applyI18n();
  await loadCrops();
  await boot(true, true);          // a guest always opens with a fresh, unsaved chat
})();
})();

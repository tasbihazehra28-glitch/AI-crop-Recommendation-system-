# Crop Prediction Program (command line)
# Run:  python predict_crop.py

import model_utils as mu

trained = mu.train()
model = trained["model"]

print("=== AI CROP RECOMMENDATION SYSTEM ===")
print(f"Model: Decision Tree | test accuracy {trained['accuracy'] * 100:.2f}%")
print("Enter soil and climate values.\n")

values = {}
for feature in mu.FEATURES:
    name, unit = mu.FEATURE_INFO[feature]
    lo, hi = mu.FEATURE_LIMITS[feature]
    label = f"{name} [{unit}]" if unit else name
    while True:
        try:
            value = float(input(f"Enter {label} ({lo}-{hi}): "))
        except ValueError:
            print("Please enter a numeric value.")
            continue
        if lo <= value <= hi:
            values[feature] = value
            break
        print(f"Value must be between {lo} and {hi}.")

top = mu.predict_top(model, values, k=3)
print("\n--------------------------------")
print("Recommended Crop:", top[0][0].upper())
print("Top 3:", ", ".join(f"{c} ({p * 100:.0f}%)" for c, p in top))
print("--------------------------------")

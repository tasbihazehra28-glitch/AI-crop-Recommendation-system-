"""
advisor.py
----------
Smart helpers used by the web app and the chatbot:

  * match_problems()  - understands a farmer's problem (English / Roman Urdu / Urdu)
  * build_report()    - full recommendation report: top-3 crops, decision rules,
                        soil health check, fertilizer plan, sowing calendar, tips
  * problem_card()    - a problem + solution formatted for the chat / panel
"""

import re

import model_utils as mu
from knowledge_base import (CATEGORIES, CROP_EMOJI, CROP_UR, CROPS, GENERIC_PROBLEM_WORDS,
                            PROBLEM_BY_ID, PROBLEMS)

IDX = {"en": 0, "ur": 1}


def L(pair, lang):
    """Pick the English or Urdu version of an (en, ur) pair."""
    return pair[IDX.get(lang, 0)]


def crop_name(crop, lang):
    return CROP_UR.get(crop, crop.title()) if lang == "ur" else crop.title()


# ------------------------------------------------------------------ problems
_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")


def _has(text, kw):
    kw = kw.lower()
    if re.search(r"[a-z]", kw):               # latin keyword: whole-word match
        return re.search(r"(?<![a-z0-9])" + re.escape(kw) + r"(?![a-z0-9])", text) is not None
    return re.search(r"(?<!\w)" + re.escape(kw), text) is not None   # Urdu script: match from a word start


def match_problems(text, crop=None, limit=3):
    """Return [(problem, score), ...] best first. Empty list = nothing understood."""
    text = (text or "").lower().translate(_DIGITS)
    text = text.replace("’", "'")
    scored = []
    for p in PROBLEMS:
        score = 0.0
        for kw in p["kw"]:
            if _has(text, kw):
                score += 1.0 + 0.6 * len(kw.split())
        if score <= 0:
            continue
        if p["crops"]:
            if crop and crop in p["crops"]:
                score += 1.5
            elif crop:
                score *= 0.5
        scored.append((p, score))
    scored.sort(key=lambda s: s[1], reverse=True)
    return [s for s in scored if s[1] >= 1.6][:limit]


def is_generic_problem(text):
    text = (text or "").lower()
    return any(_has(text, w) for w in GENERIC_PROBLEM_WORDS)


def problem_card(p, lang, crop=None):
    """JSON-friendly dict describing one problem and its solution."""
    return {
        "id": p["id"],
        "category": CATEGORIES[p["cat"]][IDX[lang]],
        "title": L(p["title"], lang),
        "cause": L(p["cause"], lang),
        "steps": p["steps"][IDX[lang]],
        "prevent": p["prevent"][IDX[lang]],
        "crop": crop_name(crop, lang) if crop else None,
        "warning": ("⚠ کیمیکل/دوا ہمیشہ پیکٹ پر لکھی مقدار کے مطابق ہی استعمال کریں اور اپنے محکمۂ زراعت کے افسر سے مشورہ لیں۔"
                    if lang == "ur" else
                    "⚠ Always follow the product label for any chemical and confirm with your local agriculture officer."),
    }


def problem_catalog(lang):
    """All problems grouped by category (for the Problem Solver panel)."""
    groups = {}
    for p in PROBLEMS:
        groups.setdefault(p["cat"], []).append({"id": p["id"], "title": L(p["title"], lang)})
    return [{"key": k, "label": CATEGORIES[k][IDX[lang]], "items": v} for k, v in groups.items()]


def crop_problems(crop, lang):
    return [{"id": pid, "title": L(PROBLEM_BY_ID[pid]["title"], lang)}
            for pid in CROPS[crop]["problems"] if pid in PROBLEM_BY_ID]


# ------------------------------------------------------------- crop details
def crop_card(crop, lang, profile=None):
    c = CROPS[crop]
    card = {
        "crop": crop, "name": crop_name(crop, lang), "emoji": CROP_EMOJI[crop],
        "season": L(c["season"], lang), "sow": L(c["sow"], lang),
        "harvest": L(c["harvest"], lang), "duration": L(c["duration"], lang),
        "water": L(c["water"], lang), "tips": c["tips"][IDX[lang]],
        "dose": dict(zip(("N", "P", "K"), c["dose"])),
        "problems": crop_problems(crop, lang),
    }
    if profile:
        card["ideal"] = []
        for f in mu.FEATURES:
            lo, hi, _ = profile[f]
            name, unit = mu.FEATURE_INFO[f]
            card["ideal"].append({"feature": f, "label": feature_label(f, lang),
                                  "low": round(lo, 1), "high": round(hi, 1), "unit": unit})
    return card


FEATURE_UR = {
    "N": "نائٹروجن (N)", "P": "فاسفورس (P)", "K": "پوٹاشیم (K)",
    "temperature": "درجہ حرارت", "humidity": "نمی (ہوا میں)", "ph": "مٹی کا pH", "rainfall": "بارش",
}


def feature_label(f, lang):
    return FEATURE_UR[f] if lang == "ur" else mu.FEATURE_INFO[f][0]


# --------------------------------------------------------------- soil health
SOIL_ADVICE = {
    "N": {"low": ("Nitrogen is lower than {crop} usually likes. Add urea/compost and give it in split doses.",
                  "{crop} کے لیے نائٹروجن کم ہے۔ یوریا/کمپوسٹ ڈالیں اور کئی قسطوں میں دیں۔"),
          "high": ("Nitrogen is higher than usual. Skip extra urea - too much causes weak stems and more pests.",
                   "نائٹروجن معمول سے زیادہ ہے۔ اضافی یوریا نہ ڈالیں - زیادہ ہونے پر تنے کمزور اور کیڑے زیادہ ہوتے ہیں۔")},
    "P": {"low": ("Phosphorus is low. Apply DAP or SSP at sowing near the roots.",
                  "فاسفورس کم ہے۔ بوائی کے وقت DAP یا SSP جڑوں کے قریب ڈالیں۔"),
          "high": ("Phosphorus is already high. You can skip DAP/SSP this season.",
                   "فاسفورس پہلے سے زیادہ ہے۔ اس موسم میں DAP/SSP چھوڑ سکتے ہیں۔")},
    "K": {"low": ("Potassium is low. Apply MOP/SOP to improve strength and quality.",
                  "پوٹاشیم کم ہے۔ مضبوطی اور معیار کے لیے MOP/SOP ڈالیں۔"),
          "high": ("Potassium is high. No extra potash needed now.",
                   "پوٹاشیم زیادہ ہے۔ ابھی اضافی پوٹاش کی ضرورت نہیں۔")},
    "temperature": {"low": ("Your area is cooler than {crop} prefers - sow at the warmest suitable time or choose a cold-tolerant variety.",
                            "آپ کا علاقہ {crop} کے لیے ٹھنڈا ہے - سب سے گرم مناسب وقت پر بوئیں یا سردی برداشت کرنے والی قسم لیں۔"),
                    "high": ("Your area is hotter than {crop} prefers - use mulch, irrigate more and choose heat-tolerant varieties.",
                             "آپ کا علاقہ {crop} کے لیے زیادہ گرم ہے - ملچ بچھائیں، زیادہ آبپاشی کریں اور گرمی برداشت کرنے والی قسم لیں۔")},
    "humidity": {"low": ("Air is drier than usual for {crop} - irrigate more often and mulch.",
                         "{crop} کے لیے ہوا زیادہ خشک ہے - آبپاشی زیادہ بار کریں اور ملچ بچھائیں۔"),
                 "high": ("Humidity is higher than usual - watch for fungal diseases and keep good spacing.",
                          "نمی معمول سے زیادہ ہے - پھپھوندی کی بیماریوں پر نظر رکھیں اور پودوں میں مناسب فاصلہ رکھیں۔")},
    "ph": {"low": ("Soil is more acidic than {crop} likes - apply agricultural lime and compost.",
                   "مٹی {crop} کے لیے زیادہ تیزابی ہے - زرعی چونا اور کمپوسٹ ڈالیں۔"),
           "high": ("Soil is more alkaline than {crop} likes - use gypsum/sulphur and organic matter.",
                    "مٹی {crop} کے لیے زیادہ اساسی (کلراٹھی) ہے - جپسم/سلفر اور نامیاتی کھاد ڈالیں۔")},
    "rainfall": {"low": ("Rainfall is less than {crop} usually needs - plan extra irrigation (drip/sprinkler saves water).",
                         "بارش {crop} کی عام ضرورت سے کم ہے - اضافی آبپاشی کا منصوبہ بنائیں (ڈرپ/سپرنکلر سے پانی بچتا ہے)۔"),
                 "high": ("Rainfall is more than usual - ensure good drainage to avoid waterlogging.",
                          "بارش معمول سے زیادہ ہے - پانی کھڑا ہونے سے بچنے کے لیے نکاسی کا اچھا انتظام رکھیں۔")},
}
OK_TEXT = ("Within the ideal range for {crop}.", "{crop} کے لیے مثالی حد میں ہے۔")


def soil_health(crop, values, profile, lang):
    rows = []
    for f in mu.FEATURES:
        lo, hi, _ = profile[f]
        v = values[f]
        status = "low" if v < lo else "high" if v > hi else "ok"
        name = crop_name(crop, lang)
        text = L(OK_TEXT, lang) if status == "ok" else L(SOIL_ADVICE[f][status], lang)
        rows.append({
            "feature": f, "label": feature_label(f, lang), "value": round(v, 2),
            "unit": mu.FEATURE_INFO[f][1], "low": round(lo, 1), "high": round(hi, 1),
            "status": status, "advice": text.format(crop=name),
        })
    ok = sum(r["status"] == "ok" for r in rows)
    return {"rows": rows, "score": round(100 * ok / len(rows))}


# ---------------------------------------------------------------- fertilizer
def fertilizer_plan(crop, values, profile, lang):
    """Nutrient dose (kg/ha) adjusted for soil status + equivalent fertilizer bags."""
    n, p, k = CROPS[crop]["dose"]
    adjust = {}
    if values:
        for f in ("N", "P", "K"):
            lo, hi, _ = profile[f]
            adjust[f] = 1.25 if values[f] < lo else 0.6 if values[f] > hi else 1.0
    else:
        adjust = {"N": 1.0, "P": 1.0, "K": 1.0}
    n, p, k = n * adjust["N"], p * adjust["P"], k * adjust["K"]

    dap = p / 0.46                       # DAP: 46 % P2O5, 18 % N
    n_from_dap = dap * 0.18
    urea = max(n - n_from_dap, 0) / 0.46  # urea: 46 % N
    mop = k / 0.60                       # MOP: 60 % K2O
    acre = 1 / 2.471

    def per(x):
        return {"ha": round(x), "acre": round(x * acre)}

    steps_en = [
        f"At sowing: all DAP ({per(dap)['acre']} kg/acre) + all MOP ({per(mop)['acre']} kg/acre) + 1/3 of urea.",
        "First top-dress: 1/3 urea about 25-30 days after sowing (after irrigation).",
        "Second top-dress: remaining 1/3 urea at flowering / grain or fruit formation.",
        "Add 2-3 tonnes of well-rotted compost per acre before ploughing if available.",
    ]
    steps_ur = [
        f"بوائی پر: پورا DAP ({per(dap)['acre']} کلو/ایکڑ) + پورا MOP ({per(mop)['acre']} کلو/ایکڑ) + یوریا کا 1/3۔",
        "پہلی ٹاپ ڈریسنگ: بوائی کے تقریباً 25-30 دن بعد 1/3 یوریا (پانی لگانے کے بعد)۔",
        "دوسری ٹاپ ڈریسنگ: باقی 1/3 یوریا پھول / دانہ یا پھل بنتے وقت۔",
        "ممکن ہو تو ہل چلانے سے پہلے فی ایکڑ 2-3 ٹن اچھی گلی سڑی کھاد ڈالیں۔",
    ]
    note_en = ("Estimate from general guidelines, adjusted to your soil values. "
               "For exact doses get a soil test or ask your local agriculture office.")
    note_ur = ("یہ عام معیارات پر مبنی اندازہ ہے جو آپ کی مٹی کی قدروں کے مطابق ایڈجسٹ کیا گیا ہے۔ "
               "درست مقدار کے لیے مٹی کا ٹیسٹ کروائیں یا اپنے محکمۂ زراعت کے دفتر سے پوچھیں۔")
    return {
        "nutrients": {"N": round(n), "P": round(p), "K": round(k)},
        "urea": per(urea), "dap": per(dap), "mop": per(mop),
        "steps": steps_ur if lang == "ur" else steps_en,
        "note": note_ur if lang == "ur" else note_en,
        "adjusted": bool(values),
    }


# -------------------------------------------------------------------- report
def build_report(model, profiles, values, lang="en"):
    top = mu.predict_top(model, values, k=3)
    crop, conf = top[0]
    prof = profiles[crop]
    card = crop_card(crop, lang)
    rules = mu.explain_prediction(model, values)
    return {
        "lang": lang,
        "crop": crop, "name": crop_name(crop, lang), "emoji": CROP_EMOJI[crop],
        "confidence": round(conf, 4),
        "top3": [{"crop": c, "name": crop_name(c, lang), "emoji": CROP_EMOJI[c], "p": round(p, 4)}
                 for c, p in top],
        "values": {f: values[f] for f in mu.FEATURES},
        "rules": rules,
        "soil": soil_health(crop, values, prof, lang),
        "fertilizer": fertilizer_plan(crop, values, prof, lang),
        "info": card,
        "disclaimer": ("براہِ کرم بوائی سے پہلے مقامی ماہرِ زراعت سے تصدیق کر لیں۔" if lang == "ur"
                       else "Please confirm with a local agriculture expert before sowing."),
    }

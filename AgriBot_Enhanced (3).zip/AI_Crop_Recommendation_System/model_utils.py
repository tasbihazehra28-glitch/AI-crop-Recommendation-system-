"""
model_utils.py
--------------
Shared machine-learning code for the AI Crop Recommendation System.

Every other file (train_model.py, predict_crop.py, crop_gui.py) imports from
here, so the dataset loading, the train/test split and the Decision Tree are
defined in exactly ONE place and always give identical results.
"""

import os

import pandas as pd
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.tree import DecisionTreeClassifier

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATASET = os.path.join(BASE_DIR, "crop_recommendation_dataset.csv")

FEATURES = ["N", "P", "K", "temperature", "humidity", "ph", "rainfall"]

# Human-friendly names and units (used by the chatbot and the CLI).
FEATURE_INFO = {
    "N": ("Nitrogen (N)", "kg/ha"),
    "P": ("Phosphorus (P)", "kg/ha"),
    "K": ("Potassium (K)", "kg/ha"),
    "temperature": ("Temperature", "°C"),
    "humidity": ("Humidity", "%"),
    "ph": ("Soil pH", ""),
    "rainfall": ("Rainfall", "mm"),
}

# Realistic limits used to validate user input.
FEATURE_LIMITS = {
    "N": (0, 300),
    "P": (0, 300),
    "K": (0, 300),
    "temperature": (-10, 60),
    "humidity": (0, 100),
    "ph": (0, 14),
    "rainfall": (0, 5000),
}

RANDOM_STATE = 42

# Hyper-parameters found with GridSearchCV (5-fold cross-validation on the
# TRAINING data only, so the test set stays unseen). See train_model.py.
BEST_PARAMS = dict(
    criterion="entropy",
    max_depth=7,
    min_samples_split=2,
    min_samples_leaf=2,
    random_state=RANDOM_STATE,
)


def load_data():
    """Load the CSV and return (X, y, full dataframe)."""
    data = pd.read_csv(DATASET)
    return data[FEATURES], data["crop"], data


def split_data(X, y):
    """80 % training / 20 % testing, stratified so every crop is represented."""
    return train_test_split(
        X, y, test_size=0.20, random_state=RANDOM_STATE, stratify=y
    )


def build_model():
    """Create an (untrained) Decision Tree with the tuned parameters."""
    return DecisionTreeClassifier(**BEST_PARAMS)


def tune_model(X_train, y_train):
    """Run GridSearchCV (used by train_model.py to justify the parameters)."""
    grid = {
        "criterion": ["entropy", "gini"],
        "max_depth": [3, 4, 5, 6, 7, 8, 10, None],
        "min_samples_split": [2, 4, 10, 20],
        "min_samples_leaf": [1, 2, 5, 10],
    }
    search = GridSearchCV(
        DecisionTreeClassifier(random_state=RANDOM_STATE),
        grid, cv=5, n_jobs=-1,
    )
    search.fit(X_train, y_train)
    return search


def train():
    """
    Train the model and return everything the apps need.

    Returns a dict with: model, accuracy, X_train, X_test, y_train, y_test,
    data (full dataframe) and crop_profiles (per-crop statistics).
    """
    X, y, data = load_data()
    X_train, X_test, y_train, y_test = split_data(X, y)

    model = build_model()
    model.fit(X_train, y_train)
    accuracy = model.score(X_test, y_test)

    return {
        "model": model,
        "accuracy": accuracy,
        "X_train": X_train,
        "X_test": X_test,
        "y_train": y_train,
        "y_test": y_test,
        "data": data,
        "crop_profiles": crop_profiles(data),
    }


def crop_profiles(data):
    """Typical range (10th - 90th percentile) of each feature for each crop."""
    profiles = {}
    for crop, group in data.groupby("crop"):
        profiles[crop] = {
            f: (float(group[f].quantile(0.10)), float(group[f].quantile(0.90)),
                float(group[f].mean()))
            for f in FEATURES
        }
    return profiles


def predict_top(model, values, k=3):
    """
    Predict for one set of values.
    Returns a list of (crop, probability) sorted best-first.
    """
    row = pd.DataFrame([[values[f] for f in FEATURES]], columns=FEATURES)
    probs = model.predict_proba(row)[0]
    ranked = sorted(zip(model.classes_, probs), key=lambda p: p[1], reverse=True)
    return [(str(c), float(p)) for c, p in ranked[:k]]


def explain_prediction(model, values):
    """
    Return the real decision rules the tree followed for this input,
    as a list of readable strings, e.g. 'rainfall = 210.0 > 150.2'.
    """
    row = pd.DataFrame([[values[f] for f in FEATURES]], columns=FEATURES)
    tree = model.tree_
    node_ids = model.decision_path(row).indices
    leaf = model.apply(row)[0]
    rules = []
    for node in node_ids:
        if node == leaf:
            continue
        feat = FEATURES[tree.feature[node]]
        thr = tree.threshold[node]
        val = values[feat]
        sign = "<=" if val <= thr else ">"
        rules.append(f"{feat} = {val:g} {sign} {thr:.1f}")
    return rules

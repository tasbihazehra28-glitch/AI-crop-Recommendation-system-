AgriBot - AI Crop Recommendation System  (Web App + Chatbot)
============================================================

Algorithm : Decision Tree Classifier (entropy, max_depth=7, tuned with GridSearchCV)
Inputs    : N, P, K, temperature, humidity, ph, rainfall
Output    : recommended crop (10 crops) + top-3 + soil check + fertilizer plan + sowing calendar

HOW TO RUN (easiest)
--------------------
Windows : double-click  run_agribot.bat
Mac/Linux: ./run_agribot.sh
Manual  : pip install -r requirements.txt
          python app.py
The browser opens automatically at http://127.0.0.1:5000
To open on a phone (same Wi-Fi):  python app.py --lan   and use the "On your phone" address.

NEW FEATURES (added in this version)
------------------------------------
1. Responsive web interface - works on laptop, tablet and phone (bottom menu on mobile).
2. Simple navigation bar: only "Chat" and "Recommend" (the guided form). Everything else
   (crop problems, fertilizer, sowing time, irrigation, crop information) is asked in the chat.
3. The bot never shows option buttons - it simply answers whatever the farmer types or says.
4. Farmer Problem Solver inside the chat - the farmer describes a problem (pest, disease, yellow
   leaves, waterlogging, drought, salty soil, weeds, low yield ...) in English, Roman Urdu or Urdu
   and gets: cause -> step-by-step solution -> prevention. 31 problems, English + Urdu.
5. Sign-in: click "Sign in" (top right). ANY username/email + ANY password works - a new name
   creates the account automatically (demo mode, see ANY_PASSWORD_LOGIN in app.py).
   * Signed in  -> your recent chats (last 5) are saved and shown in the sidebar.
   * Not signed in (guest) -> you can chat normally, but chats are NOT saved.
6. English / Urdu (اردو) switch for the whole interface and the bot's answers.
7. Voice input (microphone, Chrome) and "listen" button on bot replies.
8. Guided recommendation form (7 fields, validation, "try example", empty = typical value).
9. Full recommendation report: top-3 crops with bars, soil & climate check (low/ok/high with advice),
   fertilizer plan (urea / DAP / MOP kg per acre, adjusted to the soil values), sowing & harvest time,
   irrigation advice, tips, and the real Decision Tree rules used.
10. Printable report (Print / Save as PDF) and "My reports" history.

FILES
-----
app.py               - web server (Flask): pages, API, sign-in, reports
web_bot.py           - chatbot = original brain + problem solver + Urdu + new intents
chatbot_engine.py    - original chatbot brain (intents, memory, 7-question flow)
advisor.py           - problem matching, soil check, fertilizer plan, report builder
knowledge_base.py    - crop facts and the 31 farmer problems (English + Urdu)
model_utils.py       - dataset loading + Decision Tree (shared by everything)
templates/, static/  - web pages (index.html, report.html), style.css, app.js, tree picture
data/                - created automatically: users database, saved chats, reports
train_model.py       - trains/tunes/evaluates the model and prints metrics
predict_crop.py      - command-line prediction;  crop_gui.py - old Tkinter version (still works)
test_chatbot.py, test_web.py - automated tests
REPORT_CONTENT.txt, PRESENTATION_CONTENT.txt - material for report and slides

DEMO SCRIPT FOR YOUR TEACHER (5 minutes)
----------------------------------------
1. Open the app (it starts as a guest - chats are not saved).
2. Chat: type "hello" -> "recommend a crop" -> answer the 7 questions (or paste
   N=90 P=42 K=40 temp=26 humidity=82 ph=6.1 rainfall=210) -> show the report card.
3. Type "why", "fertilizer advice", then press "Print / PDF report".
4. Type a problem: "mere gehun ke patte peele ho rahe hain" and "wheat yellow rust" -> show solutions.
5. Switch to اردو (top right) and ask: "کھیت میں پانی کھڑا ہو گیا".
6. Click the microphone and speak a problem (Chrome).
7. Click "Sign in", enter any name and password -> chat again and show the chat in "Recent chats".
8. Open the "Recommend" page -> "My reports".

IMPORTANT ACADEMIC NOTE
-----------------------
The dataset is an educational synthetic dataset; several crops overlap in their soil/climate
values, so test accuracy is about 61% (cross-validation about 63%). The app shows this honestly.
The 100% "match" shown on a result is how pure the Decision Tree leaf is, not the real accuracy.
Problem advice is general guidance: chemicals are mentioned only as examples and the user is
always told to follow the product label and ask the local agriculture officer.

@echo off
cd /d "%~dp0"
echo Installing requirements (first time only)...
python -m pip install -r requirements.txt
echo.
echo Starting AgriBot - browser will open automatically...
python app.py
pause

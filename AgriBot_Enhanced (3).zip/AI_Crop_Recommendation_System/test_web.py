"""Automated tests for the new AgriBot features.  Run:  python test_web.py"""
import os, tempfile
import advisor, model_utils as mu
from web_bot import WebBot

trained = mu.train()
bot = WebBot(os.path.join(tempfile.mkdtemp(), "h.json"), trained)
bot.new_chat()
fails = 0

def check(name, cond):
    global fails
    print(("PASS  " if cond else "FAIL  ") + name)
    fails += 0 if cond else 1

def last(msg):
    r = bot.handle(msg)
    return r[0] if r else {"text": "", "extra": {}}

# problem solver (English / Roman Urdu / Urdu)
for q, pid in [("my wheat has yellow rust", "rust"), ("patte peele ho rahe hain", "n_def"),
               ("aphids on my cotton", "aphids"), ("کھیت میں پانی کھڑا ہو گیا", "waterlogging"),
               ("tomato late blight", "blight"), ("too many weeds", "weeds"),
               ("میری کپاس میں سفید مکھی ہے", "whitefly"), ("my soil is saline", "saline_soil")]:
    m = last(q)
    check(f"problem '{q}' -> {pid}", m.get("extra", {}).get("problem", {}).get("id") == pid)
check("every problem has steps in both languages",
      all(p["steps"][0] and p["steps"][1] and len(p["steps"][0]) == len(p["steps"][1]) for p in advisor.PROBLEMS))

# features
check("fertilizer asks crop", "crop" in last("fertilizer advice")["text"].lower())
check("fertilizer for wheat", "Urea" in last("wheat")["text"])
check("sowing calendar", "Sowing" in last("when to sow rice")["text"])
check("irrigation", "Irrigation" in last("irrigation for maize")["text"])
check("generic problem prompt asks what you see (no option buttons)",
      "what you see" in last("I have a problem")["text"] and not last("I have a problem").get("extra", {}).get("chips"))

# original flow still works + report
bot.handle("start")
for v in ["90", "42", "40", "26", "82", "6.1", "210"]:
    r = bot.handle(v)
check("recommendation produces report card", r[1].get("extra", {}).get("report", {}).get("crop") in bot.crops)
check("soil health answer", "Soil health" in last("soil health")["text"])
check("original engine question still works", "Nitrogen" in last("what is nitrogen")["text"])
check("memory still works", "topic" in last("what was the last topic?")["text"].lower())

# Urdu mode
bot.lang = "ur"
bot.handle("شروع")
check("Urdu question text", "مرحلہ" in bot.handle("90")[-1]["text"])
check("invalid value rejected", "⚠" in bot.handle("999")[0]["text"])

print("\nAll tests passed" if not fails else f"\n{fails} test(s) FAILED")

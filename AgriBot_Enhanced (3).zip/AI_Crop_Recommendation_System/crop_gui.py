"""
crop_gui.py  -  AgriBot: AI Crop Recommendation Chatbot (graphical interface)

Run:  python crop_gui.py

All intelligence lives in chatbot_engine.py (intent matching, memory,
Decision Tree prediction). This file only draws the chat window.
Your 5 most recent chats are saved automatically in chat_history.json.
"""

import os
import tkinter as tk
from datetime import datetime
from tkinter import filedialog, messagebox

import chatbot_engine as ce

# ---------------------------------------------------------------- colours
SIDEBAR = "#0F3D24"          # deep forest green sidebar
SIDEBAR_ITEM = "#166534"     # chat buttons in sidebar
SIDEBAR_LINE = "#1F6B43"
SIDEBAR_SUB = "#A7F3D0"
SIDEBAR_LABEL = "#6EE7B7"

WHITE = "#FFFFFF"
CHAT_BG = "#F0FDF4"          # soft mint chat background
DARK_GREEN = "#14532D"
GREEN = "#16A34A"
GREEN_DARK = "#15803D"
LIGHT_GREEN = "#ECFDF5"
MINT = "#BBF7D0"

ACCENT = "#F59E0B"           # amber / golden accent
ACCENT_DARK = "#D97706"
SUN = "#FEF08A"
SUN_SOFT = "#FDE68A"

TEXT = "#1F2937"
SECONDARY = "#6B7280"
USER_BG = GREEN
BORDER = "#D1FAE5"
ACTIVE_CHAT = GREEN

HEADER_BG = GREEN_DARK
STATUS_ON = "#BBF7D0"
STATUS_TYPING = "#FEF08A"

PLACEHOLDER = "Type your message..."
TYPING_DELAY_MS = 350


class AgriBotApp:
    def __init__(self, root):
        self.root = root
        self.bot = ce.AgriBot()
        self.queue = []          # bot messages waiting to be shown
        self.busy = False
        self.user = None         # logged-in username/email (None = not logged in)

        root.title("AgriBot - AI Crop Recommendation Assistant")
        root.geometry("1250x780")
        root.minsize(1000, 650)
        root.configure(bg=CHAT_BG)

        self._build_sidebar()
        self._build_main()

        # Start a fresh chat; older chats stay in the sidebar.
        self.start_new_chat()
        root.protocol("WM_DELETE_WINDOW", self.on_close)

    # ------------------------------------------------------------------ layout
    def _build_sidebar(self):
        sb = tk.Frame(self.root, bg=SIDEBAR, width=260)
        sb.pack(side="left", fill="y")
        sb.pack_propagate(False)

        # golden strip at the top of the sidebar
        tk.Frame(sb, bg=ACCENT, height=5).pack(fill="x")

        logo = tk.Frame(sb, bg=SIDEBAR)
        logo.pack(fill="x", padx=18, pady=20)
        tk.Label(logo, text="🌱", font=("Segoe UI Emoji", 26), bg=SIDEBAR).pack(side="left")
        box = tk.Frame(logo, bg=SIDEBAR)
        box.pack(side="left", padx=8)
        tk.Label(box, text="AgriBot", font=("Segoe UI", 18, "bold"),
                 bg=SIDEBAR, fg=WHITE).pack(anchor="w")
        tk.Label(box, text="AI Crop Assistant", font=("Segoe UI", 9),
                 bg=SIDEBAR, fg=SIDEBAR_SUB).pack(anchor="w")

        tk.Button(sb, text="＋  New Chat", command=self.start_new_chat,
                  font=("Segoe UI", 10, "bold"), bg=ACCENT, fg=TEXT,
                  activebackground=ACCENT_DARK, activeforeground=WHITE,
                  relief="flat", bd=0, cursor="hand2",
                  anchor="w", padx=15, pady=11).pack(fill="x", padx=15, pady=(5, 18))

        tk.Label(sb, text="RECENT CHATS (last 5)", font=("Segoe UI", 8, "bold"),
                 bg=SIDEBAR, fg=SIDEBAR_LABEL).pack(anchor="w", padx=20, pady=(5, 8))

        self.chat_list = tk.Frame(sb, bg=SIDEBAR)
        self.chat_list.pack(fill="x")

        tk.Frame(sb, bg=SIDEBAR_LINE, height=1).pack(fill="x", padx=15, pady=20)

        tk.Button(sb, text="ℹ  About AgriBot", command=self.show_about,
                  font=("Segoe UI", 9), bg=SIDEBAR, fg=WHITE,
                  activebackground=SIDEBAR_ITEM, activeforeground=WHITE,
                  relief="flat", anchor="w", padx=20, cursor="hand2").pack(fill="x", pady=3)

    def _build_main(self):
        main = tk.Frame(self.root, bg=CHAT_BG)
        main.pack(side="right", fill="both", expand=True)

        header = tk.Frame(main, bg=HEADER_BG, height=65)
        header.pack(fill="x")
        header.pack_propagate(False)
        self.title_label = tk.Label(header, text="AI Crop Recommendation",
                                    font=("Segoe UI", 13, "bold"), bg=HEADER_BG, fg=WHITE)
        self.title_label.pack(side="left", padx=28)
        self.login_btn = tk.Button(header, text="🔑  Login", command=self.on_login_click,
                                   font=("Segoe UI", 10, "bold"), bg=ACCENT, fg=TEXT,
                                   activebackground=ACCENT_DARK, activeforeground=WHITE,
                                   relief="flat", bd=0, cursor="hand2", padx=16, pady=6)
        self.login_btn.pack(side="right", padx=(0, 25))
        self.status = tk.Label(header, text="● Online", font=("Segoe UI", 9, "bold"),
                               bg=HEADER_BG, fg=STATUS_ON)
        self.status.pack(side="right", padx=(0, 18))

        # golden line under the header
        tk.Frame(main, bg=ACCENT, height=3).pack(fill="x")

        # --- scrollable chat area
        container = tk.Frame(main, bg=CHAT_BG)
        container.pack(fill="both", expand=True)
        self.canvas = tk.Canvas(container, bg=CHAT_BG, highlightthickness=0)
        scrollbar = tk.Scrollbar(container, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)

        self.messages = tk.Frame(self.canvas, bg=CHAT_BG)
        self.window_id = self.canvas.create_window((0, 0), window=self.messages, anchor="nw")
        self.canvas.bind("<Configure>", self._on_canvas_resize)
        self.messages.bind("<Configure>", self._on_frame_resize)
        for seq in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            self.root.bind_all(seq, self._on_mousewheel)

        # --- input bar
        area = tk.Frame(main, bg=CHAT_BG)
        area.pack(fill="x")
        box = tk.Frame(area, bg=WHITE, highlightbackground=GREEN, highlightthickness=2)
        box.pack(fill="x", padx=45, pady=18)

        self.plus_btn = tk.Button(box, text="＋", command=self.show_attach_menu,
                                  font=("Segoe UI", 16, "bold"), bg=LIGHT_GREEN, fg=GREEN_DARK,
                                  activebackground=MINT, activeforeground=DARK_GREEN,
                                  relief="flat", bd=0, cursor="hand2", width=3)
        self.plus_btn.pack(side="left", padx=(7, 0), pady=6)

        self.entry = tk.Entry(box, font=("Segoe UI", 11), bg=WHITE, fg=SECONDARY,
                              relief="flat", bd=0)
        self.entry.pack(side="left", fill="both", expand=True, padx=(10, 8), pady=13)
        self.entry.insert(0, PLACEHOLDER)
        self.entry.bind("<FocusIn>", self._clear_placeholder)
        self.entry.bind("<FocusOut>", self._restore_placeholder)
        self.entry.bind("<Return>", lambda e: self.send())

        tk.Button(box, text="➤", command=self.send, font=("Segoe UI", 15, "bold"),
                  bg=GREEN, fg=WHITE, activebackground=ACCENT_DARK, activeforeground=WHITE,
                  relief="flat", cursor="hand2", width=3).pack(side="right", padx=7, pady=6)

    # ---------------------------------------------------------------- scrolling
    def _on_canvas_resize(self, event):
        self.canvas.itemconfig(self.window_id, width=event.width)

    def _on_frame_resize(self, _event):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _on_mousewheel(self, event):
        if event.num == 4:
            delta = -1
        elif event.num == 5:
            delta = 1
        else:
            delta = -1 if event.delta > 0 else 1
        self.canvas.yview_scroll(delta * 3, "units")

    def scroll_to_bottom(self):
        self.root.update_idletasks()
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        self.canvas.yview_moveto(1.0)

    # ------------------------------------------------------------- placeholder
    def _clear_placeholder(self, _event=None):
        if self.entry.get() == PLACEHOLDER:
            self.entry.delete(0, tk.END)
            self.entry.config(fg=TEXT)

    def _restore_placeholder(self, _event=None):
        if not self.entry.get().strip():
            self.entry.delete(0, tk.END)
            self.entry.insert(0, PLACEHOLDER)
            self.entry.config(fg=SECONDARY)

    # ----------------------------------------------------------- message widgets
    def clear_screen(self):
        for w in self.messages.winfo_children():
            w.destroy()

    def draw_bot(self, text):
        outer = tk.Frame(self.messages, bg=CHAT_BG)
        outer.pack(fill="x", padx=70, pady=8)
        tk.Label(outer, text="🌱", font=("Segoe UI Emoji", 18), bg=MINT,
                 padx=8, pady=6).pack(side="left", anchor="n", padx=(0, 14))
        bubble = tk.Frame(outer, bg=WHITE, highlightbackground=MINT, highlightthickness=2)
        bubble.pack(side="left", anchor="w")
        tk.Label(bubble, text="AgriBot", font=("Segoe UI", 9, "bold"),
                 bg=WHITE, fg=GREEN_DARK).pack(anchor="w", padx=15, pady=(10, 2))
        tk.Label(bubble, text=text, font=("Segoe UI", 11), bg=WHITE, fg=TEXT,
                 justify="left", anchor="w", wraplength=650).pack(
            anchor="w", padx=15, pady=(0, 12))

    def draw_user(self, text):
        outer = tk.Frame(self.messages, bg=CHAT_BG)
        outer.pack(fill="x", padx=70, pady=8)
        tk.Label(outer, text="👤", font=("Segoe UI Emoji", 17), bg=SUN_SOFT,
                 padx=8, pady=6).pack(side="right", anchor="n", padx=(14, 0))
        tk.Label(outer, text=text, font=("Segoe UI", 11), bg=USER_BG, fg=WHITE,
                 padx=16, pady=11, justify="left", wraplength=600).pack(side="right")

    def draw_card(self, crop, extra):
        extra = extra or {}
        outer = tk.Frame(self.messages, bg=CHAT_BG)
        outer.pack(fill="x", padx=120, pady=16)
        card = tk.Frame(outer, bg=DARK_GREEN, highlightbackground=ACCENT,
                        highlightthickness=2)
        card.pack(fill="x")
        tk.Frame(card, bg=ACCENT, height=6).pack(fill="x")
        tk.Label(card, text="🌾", font=("Segoe UI Emoji", 38), bg=DARK_GREEN).pack(pady=(20, 2))
        tk.Label(card, text="AI RECOMMENDATION", font=("Segoe UI", 9, "bold"),
                 bg=DARK_GREEN, fg=ACCENT).pack()
        tk.Label(card, text=crop.upper(), font=("Segoe UI", 28, "bold"),
                 bg=DARK_GREEN, fg=WHITE).pack(pady=5)
        conf = extra.get("confidence")
        if conf is not None:
            tk.Label(card, text=f"Confidence: {conf * 100:.0f}%",
                     font=("Segoe UI", 10, "bold"), bg=DARK_GREEN, fg=SUN).pack()
        alts = [f"{c.title()} {p * 100:.0f}%" for c, p in extra.get("alternatives", []) if p > 0]
        if alts:
            tk.Label(card, text="Other possibilities: " + "  ·  ".join(alts),
                     font=("Segoe UI", 9), bg=DARK_GREEN, fg=SIDEBAR_SUB).pack(pady=(3, 0))
        tk.Label(card, text="Recommended based on your soil and climate conditions",
                 font=("Segoe UI", 9), bg=DARK_GREEN, fg=MINT).pack(pady=(4, 20))

    def draw_message(self, msg):
        sender = msg["sender"]
        if sender == "user":
            self.draw_user(msg["text"])
        elif sender == "card":
            self.draw_card(msg["text"], msg.get("extra"))
        else:
            self.draw_bot(msg["text"])

    # ------------------------------------------------------------- chat control
    def refresh_sidebar(self):
        for w in self.chat_list.winfo_children():
            w.destroy()
        for chat in self.bot.recent_chats():
            active = chat is self.bot.current
            title = chat["title"] if len(chat["title"]) <= 26 else chat["title"][:25] + "…"
            when = datetime.fromisoformat(chat["created"]).strftime("%d %b, %H:%M")
            tk.Button(self.chat_list, text=f"💬  {title}\n      {when}",
                      command=lambda c=chat: self.open_chat(c["id"]),
                      font=("Segoe UI", 9), justify="left",
                      bg=ACTIVE_CHAT if active else SIDEBAR_ITEM, fg=WHITE,
                      activebackground=GREEN, activeforeground=WHITE,
                      relief="flat", bd=0, anchor="w",
                      padx=12, pady=7, cursor="hand2").pack(fill="x", padx=10, pady=2)
        current = self.bot.current
        self.title_label.config(
            text=current["title"] if current and current["title"] != "New chat"
            else "AI Crop Recommendation")

    def start_new_chat(self):
        self.queue = []
        replies = self.bot.new_chat()
        self.clear_screen()
        self.refresh_sidebar()
        self.show_replies(replies, animate=False)

    def open_chat(self, chat_id):
        self.queue = []
        messages = self.bot.open_chat(chat_id)
        self.clear_screen()
        for msg in messages:
            self.draw_message(msg)
        self.refresh_sidebar()
        self.scroll_to_bottom()

    # ------------------------------------------------------------ sending / queue
    def send(self):
        text = self.entry.get().strip()
        if not text or text == PLACEHOLDER:
            return
        self.entry.delete(0, tk.END)
        self.draw_user(text)
        self.scroll_to_bottom()
        replies = self.bot.handle(text)
        self.refresh_sidebar()
        self.show_replies(replies, animate=True)

    def show_replies(self, replies, animate):
        if not animate:
            for r in replies:
                self.draw_message(r)
            self.scroll_to_bottom()
            return
        self.queue.extend(replies)
        if not self.busy:
            self.status.config(text="● typing...", fg=STATUS_TYPING)
            self.busy = True
            self.root.after(TYPING_DELAY_MS, self._show_next)

    def _show_next(self):
        if not self.queue:
            self.busy = False
            self.status.config(text="● Online", fg=STATUS_ON)
            return
        self.draw_message(self.queue.pop(0))
        self.scroll_to_bottom()
        self.root.after(TYPING_DELAY_MS, self._show_next)

    # ------------------------------------------------------------ attach (+) menu
    def show_attach_menu(self):
        menu = tk.Menu(self.root, tearoff=0, font=("Segoe UI", 10), bg=WHITE, fg=TEXT,
                       activebackground=GREEN, activeforeground=WHITE, bd=1, relief="solid")
        menu.add_command(label="🖼   Add Images", command=self.add_images)
        menu.add_separator()
        menu.add_command(label="📎   Add Files", command=self.add_files)
        menu.update_idletasks()
        x = self.plus_btn.winfo_rootx()
        y = self.plus_btn.winfo_rooty() - menu.winfo_reqheight() - 4   # open upwards
        try:
            menu.tk_popup(x, y)
        finally:
            menu.grab_release()

    def add_images(self):
        paths = filedialog.askopenfilenames(
            title="Select images",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.gif *.bmp *.webp"),
                       ("All files", "*.*")])
        self._attach(paths, "🖼")

    def add_files(self):
        paths = filedialog.askopenfilenames(title="Select files")
        self._attach(paths, "📎")

    def _attach(self, paths, icon):
        for path in paths:
            self.draw_user(f"{icon}  {os.path.basename(path)}")
        if paths:
            count = len(paths)
            self.draw_bot("Attached successfully." if count == 1
                          else f"{count} files attached successfully.")
            self.scroll_to_bottom()

    # ---------------------------------------------------------------- login
    def on_login_click(self):
        if self.user:
            if messagebox.askyesno("Logout", f"Logged in as {self.user}.\n\nDo you want to logout?"):
                self.user = None
                self.login_btn.config(text="🔑  Login")
            return
        self.open_login_dialog()

    def open_login_dialog(self):
        win = tk.Toplevel(self.root)
        win.title("Login - AgriBot")
        win.configure(bg=WHITE)
        win.resizable(False, False)
        win.transient(self.root)

        w, h = 380, 400
        x = self.root.winfo_rootx() + (self.root.winfo_width() - w) // 2
        y = self.root.winfo_rooty() + (self.root.winfo_height() - h) // 2
        win.geometry(f"{w}x{h}+{x}+{y}")

        top = tk.Frame(win, bg=DARK_GREEN)
        top.pack(fill="x")
        tk.Frame(top, bg=ACCENT, height=5).pack(fill="x")
        tk.Label(top, text="🌱", font=("Segoe UI Emoji", 28), bg=DARK_GREEN).pack(pady=(14, 0))
        tk.Label(top, text="Welcome to AgriBot", font=("Segoe UI", 14, "bold"),
                 bg=DARK_GREEN, fg=WHITE).pack()
        tk.Label(top, text="Login to continue", font=("Segoe UI", 9),
                 bg=DARK_GREEN, fg=SIDEBAR_SUB).pack(pady=(0, 14))

        form = tk.Frame(win, bg=WHITE)
        form.pack(fill="both", expand=True, padx=34, pady=(16, 0))

        tk.Label(form, text="Username or Email", font=("Segoe UI", 9, "bold"),
                 bg=WHITE, fg=DARK_GREEN).pack(anchor="w")
        user_box = tk.Frame(form, bg=WHITE, highlightbackground=GREEN, highlightthickness=1)
        user_box.pack(fill="x", pady=(3, 12))
        user_entry = tk.Entry(user_box, font=("Segoe UI", 11), relief="flat", bd=0,
                              bg=WHITE, fg=TEXT)
        user_entry.pack(fill="x", padx=10, pady=8)

        tk.Label(form, text="Password", font=("Segoe UI", 9, "bold"),
                 bg=WHITE, fg=DARK_GREEN).pack(anchor="w")
        pass_box = tk.Frame(form, bg=WHITE, highlightbackground=GREEN, highlightthickness=1)
        pass_box.pack(fill="x", pady=(3, 6))
        pass_entry = tk.Entry(pass_box, font=("Segoe UI", 11), relief="flat", bd=0,
                              bg=WHITE, fg=TEXT, show="•")
        pass_entry.pack(fill="x", padx=10, pady=8)

        error = tk.Label(form, text="", font=("Segoe UI", 9), bg=WHITE, fg="#DC2626")
        error.pack(anchor="w")

        def submit(_event=None):
            name = user_entry.get().strip()
            pw = pass_entry.get()
            if not name or not pw:
                error.config(text="Please enter username/email and password.")
                return
            self.user = name
            short = name if len(name) <= 14 else name[:13] + "…"
            self.login_btn.config(text=f"👤  {short}")
            win.destroy()

        tk.Button(form, text="Login", command=submit, font=("Segoe UI", 11, "bold"),
                  bg=GREEN, fg=WHITE, activebackground=GREEN_DARK, activeforeground=WHITE,
                  relief="flat", bd=0, cursor="hand2", pady=9).pack(fill="x", pady=(8, 0))

        win.bind("<Return>", submit)
        win.bind("<Escape>", lambda e: win.destroy())
        user_entry.focus_set()
        win.grab_set()

    # ---------------------------------------------------------------- misc
    def show_about(self):
        messagebox.showinfo(
            "About AgriBot",
            "AgriBot - Smart Crop Recommendation Assistant\n\n"
            "Tell AgriBot about your soil and weather and it will suggest the "
            "most suitable crop for your land.\n\n"
            "Your 5 most recent chats are saved automatically.")

    def on_close(self):
        self.root.destroy()


def main():
    root = tk.Tk()
    AgriBotApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()

"""
app.py  -  AgriBot web application (Flask)

Run:   python app.py          then open  http://127.0.0.1:5000
Phone: python app.py --lan    then open the "Network" address shown, from a phone on the same Wi-Fi.

Features: chatbot (Decision Tree AI), guided recommendation form, farmer problem solver
(inside the chat), sign-in (chats are saved only for signed-in users - guests can still chat),
saved reports, English / Urdu interface, printable reports.
"""

import json
import os
import secrets
import socket
import sqlite3
import sys
import threading
import uuid
import webbrowser
from datetime import datetime

from flask import Flask, g, jsonify, render_template, request, session
from werkzeug.security import check_password_hash, generate_password_hash

import advisor
import model_utils as mu
from knowledge_base import CROPS
from web_bot import WebBot

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "data")
CHATS = os.path.join(DATA, "chats")
DB_PATH = os.path.join(DATA, "agribot.db")
os.makedirs(CHATS, exist_ok=True)


def _secret():
    path = os.path.join(DATA, "secret.key")
    if not os.path.exists(path):
        with open(path, "w") as fh:
            fh.write(secrets.token_hex(32))
    with open(path) as fh:
        return fh.read().strip()


app = Flask(__name__, static_folder="static", template_folder="templates")
app.secret_key = _secret()
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                  PERMANENT_SESSION_LIFETIME=60 * 60 * 24 * 30, JSON_AS_ASCII=False)

# ------------------------------------------------------------------ AI model
print("Training the Decision Tree model ...")
TRAINED = mu.train()
MODEL, PROFILES = TRAINED["model"], TRAINED["crop_profiles"]


# ------------------------------------------------------------------ database
def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def _close(_):
    conn = g.pop("db", None)
    if conn:
        conn.close()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL, pw_hash TEXT NOT NULL, created TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS reports(
            id INTEGER PRIMARY KEY AUTOINCREMENT, owner TEXT NOT NULL, created TEXT NOT NULL,
            crop TEXT NOT NULL, confidence REAL NOT NULL, data TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_reports_owner ON reports(owner);
    """)
    conn.commit()
    conn.close()


init_db()


def save_report(owner, report):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.execute("INSERT INTO reports(owner, created, crop, confidence, data) VALUES (?,?,?,?,?)",
                       (owner, datetime.now().isoformat(timespec="seconds"), report["crop"],
                        report["confidence"], json.dumps(report, ensure_ascii=False)))
    conn.commit()
    rid = cur.lastrowid
    conn.close()
    return rid


# ------------------------------------------------------------ owners and bots
BOTS = {}
LOCK = threading.RLock()


def owner_id():
    if session.get("uid"):
        return f"u{session['uid']}"
    if not session.get("gid"):
        session["gid"] = uuid.uuid4().hex
    session.permanent = True
    return f"g{session['gid']}"


def signed_in():
    return bool(session.get("uid"))


def get_bot(owner=None):
    owner = owner or owner_id()
    with LOCK:
        if owner not in BOTS:
            if owner.startswith("u"):          # signed-in user: chats are saved on disk
                BOTS[owner] = WebBot(os.path.join(CHATS, f"{owner}.json"), TRAINED,
                                     on_report=lambda r, o=owner: save_report(o, r))
            else:                              # guest: chats live in memory only, nothing is saved
                BOTS[owner] = WebBot(os.path.join(CHATS, f"_guest_{owner}.json"), TRAINED,
                                     on_report=lambda r, o=owner: save_report(o, r), persist=False)
        return BOTS[owner]


def lang_of(data=None):
    lang = (data or {}).get("lang") or request.args.get("lang") or "en"
    return "ur" if lang == "ur" else "en"


def chat_list(bot):
    if not signed_in():                        # guests have no saved chats
        return []
    return [{"id": c["id"], "title": c["title"], "updated": c["updated"],
             "current": bot.current is not None and c["id"] == bot.current["id"],
             "count": sum(1 for m in c["messages"] if m["sender"] == "user")}
            for c in bot.recent_chats()]


def user_json():
    if not session.get("uid"):
        return None
    row = db().execute("SELECT id, username, name FROM users WHERE id=?", (session["uid"],)).fetchone()
    return dict(row) if row else None


# -------------------------------------------------------------------- pages
@app.route("/")
def index():
    return render_template("index.html")


# --------------------------------------------------------------------- chat
@app.post("/api/init")
def api_init():
    data = request.get_json(silent=True) or {}
    with LOCK:
        if data.get("fresh") and not signed_in():      # a guest always starts with an empty chat
            BOTS.pop(owner_id(), None)
        bot = get_bot()
        bot.lang = lang_of(data)
        if bot.current is None:
            bot.new_chat()
        return jsonify(messages=bot.current["messages"], chats=chat_list(bot), user=user_json(),
                       title=bot.current["title"])


@app.post("/api/chat")
def api_chat():
    data = request.get_json(silent=True) or {}
    text = str(data.get("message", ""))[:1000]
    bot = get_bot()
    with LOCK:
        bot.lang = lang_of(data)
        if bot.current is None:
            bot.new_chat()
        replies = bot.handle(text)
        bot._save()
        return jsonify(replies=replies, chats=chat_list(bot), title=bot.current["title"])


@app.post("/api/new_chat")
def api_new_chat():
    data = request.get_json(silent=True) or {}
    bot = get_bot()
    with LOCK:
        bot.lang = lang_of(data)
        bot.new_chat()
        return jsonify(messages=bot.current["messages"], chats=chat_list(bot), title=bot.current["title"])


@app.post("/api/open_chat")
def api_open_chat():
    data = request.get_json(silent=True) or {}
    bot = get_bot()
    with LOCK:
        bot.lang = lang_of(data)
        msgs = bot.open_chat(str(data.get("id", "")))
        return jsonify(messages=msgs, chats=chat_list(bot), title=bot.current["title"])


@app.post("/api/delete_chat")
def api_delete_chat():
    data = request.get_json(silent=True) or {}
    bot = get_bot()
    with LOCK:
        bot.lang = lang_of(data)
        cid = str(data.get("id", ""))
        bot.chats = [c for c in bot.chats if c["id"] != cid]
        if bot.current and bot.current["id"] == cid:
            bot.current = None
            bot.new_chat()
        else:
            bot._save()
        return jsonify(messages=bot.current["messages"], chats=chat_list(bot), title=bot.current["title"])


# ------------------------------------------------- guided form recommendation
@app.post("/api/recommend")
def api_recommend():
    data = request.get_json(silent=True) or {}
    lang = lang_of(data)
    raw = data.get("values") or {}
    bot = get_bot()
    values, assumed, errors = {}, [], {}
    for f in mu.FEATURES:
        v = raw.get(f)
        if v in (None, ""):
            values[f] = bot.means[f]
            assumed.append(f)
            continue
        try:
            v = float(v)
        except (TypeError, ValueError):
            errors[f] = "number"
            continue
        lo, hi = mu.FEATURE_LIMITS[f]
        if not lo <= v <= hi:
            errors[f] = f"{lo}-{hi}"
            continue
        values[f] = v
    if errors:
        return jsonify(error="invalid", fields=errors), 400
    if len(assumed) == len(mu.FEATURES):
        return jsonify(error="empty"), 400
    report = advisor.build_report(MODEL, PROFILES, values, lang)
    report["assumed"] = [advisor.feature_label(f, lang) for f in assumed]
    report["id"] = save_report(owner_id(), report)
    return jsonify(report=report)


# -------------------------------------------------------------- crop library
@app.get("/api/crops")
def api_crops():
    lang = lang_of()
    return jsonify(crops=[advisor.crop_card(c, lang, PROFILES[c]) for c in sorted(CROPS)])


# ------------------------------------------------------------------ reports
@app.get("/api/reports")
def api_reports():
    rows = db().execute("SELECT id, created, crop, confidence FROM reports WHERE owner=? ORDER BY id DESC LIMIT 30",
                        (owner_id(),)).fetchall()
    return jsonify(reports=[dict(r) for r in rows], signed_in=bool(session.get("uid")))


def _load_report(rid):
    row = db().execute("SELECT data FROM reports WHERE id=? AND owner=?", (rid, owner_id())).fetchone()
    return json.loads(row["data"]) if row else None


@app.get("/api/report/<int:rid>")
def api_report(rid):
    r = _load_report(rid)
    if not r:
        return jsonify(error="not found"), 404
    lang = lang_of()
    if r.get("lang") != lang:          # re-create in the requested language
        r = advisor.build_report(MODEL, PROFILES, r["values"], lang)
        r["id"] = rid
    return jsonify(report=r)


@app.get("/report/<int:rid>")
def report_page(rid):
    r = _load_report(rid)
    if not r:
        return "Report not found", 404
    lang = lang_of()
    r = advisor.build_report(MODEL, PROFILES, r["values"], lang)
    return render_template("report.html", r=r, lang=lang, rid=rid,
                           date=datetime.now().strftime("%d %b %Y, %H:%M"))


@app.post("/api/report/<int:rid>/delete")
def api_report_delete(rid):
    db().execute("DELETE FROM reports WHERE id=? AND owner=?", (rid, owner_id()))
    db().commit()
    return jsonify(ok=True)


# --------------------------------------------------------------------- auth
# Demo mode: ANY username/email + ANY password signs in. A new name simply creates the account.
# Set this to False if you want real password checking for existing accounts.
ANY_PASSWORD_LOGIN = True


def _merge_guest(guest_owner, user_owner):
    """Reports made as a guest move into the account. Guest chats are never saved."""
    if not guest_owner or guest_owner == user_owner:
        return
    with LOCK:
        BOTS.pop(guest_owner, None)
    db().execute("UPDATE reports SET owner=? WHERE owner=?", (user_owner, guest_owner))
    db().commit()


def _sign_in(uid):
    guest = f"g{session['gid']}" if session.get("gid") else None
    session.clear()
    session["uid"] = uid
    session.permanent = True
    _merge_guest(guest, f"u{uid}")


def _login_or_create(username, password, name=None):
    """Return (user id, None) or (None, error code)."""
    username = str(username or "").strip()[:60]
    password = str(password or "")
    if not username or not password:
        return None, "missing"
    key = username.lower()
    row = db().execute("SELECT * FROM users WHERE username=?", (key,)).fetchone()
    if row:
        if not ANY_PASSWORD_LOGIN and not check_password_hash(row["pw_hash"], password):
            return None, "credentials"
        return row["id"], None
    display = (str(name or "").strip() or username)[:40]
    cur = db().execute("INSERT INTO users(username, name, pw_hash, created) VALUES (?,?,?,?)",
                       (key, display, generate_password_hash(password),
                        datetime.now().isoformat(timespec="seconds")))
    db().commit()
    return cur.lastrowid, None


@app.post("/api/register")
def api_register():
    d = request.get_json(silent=True) or {}
    uid, err = _login_or_create(d.get("username"), d.get("password"), d.get("name"))
    if err:
        return jsonify(error=err), 400
    _sign_in(uid)
    return jsonify(user=user_json())


@app.post("/api/login")
def api_login():
    d = request.get_json(silent=True) or {}
    uid, err = _login_or_create(d.get("username"), d.get("password"))
    if err:
        return jsonify(error=err), 400 if err == "missing" else 401
    _sign_in(uid)
    return jsonify(user=user_json())


@app.post("/api/logout")
def api_logout():
    session.clear()
    return jsonify(ok=True)


@app.get("/api/me")
def api_me():
    return jsonify(user=user_json())


# --------------------------------------------------------------------- main
def _lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return None


if __name__ == "__main__":
    lan = "--lan" in sys.argv
    port = int(os.environ.get("PORT", 5000))
    host = "0.0.0.0" if lan else "127.0.0.1"
    print("\n" + "=" * 54)
    print("  AgriBot is running")
    print(f"  Open in browser : http://127.0.0.1:{port}")
    if lan and _lan_ip():
        print(f"  On your phone   : http://{_lan_ip()}:{port}   (same Wi-Fi)")
    print("  Press Ctrl+C to stop")
    print("=" * 54 + "\n")
    if os.environ.get("NO_BROWSER") != "1":
        threading.Timer(1.2, lambda: webbrowser.open(f"http://127.0.0.1:{port}")).start()
    app.run(host=host, port=port, debug=False, threaded=True)

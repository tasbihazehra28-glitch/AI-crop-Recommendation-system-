"""Automated tests for AgriBot. Run:  python test_chatbot.py"""
import os
import tempfile

import chatbot_engine as ce

HIST = os.path.join(tempfile.mkdtemp(), "history.json")
bot = ce.AgriBot(history_file=HIST)
first = bot.new_chat()


def ask(text):
    return "\n".join(r["text"] for r in bot.handle(text))


def check(name, condition):
    print(("PASS  " if condition else "FAIL  ") + name)
    if not condition:
        raise SystemExit(1)


# ---- conversation flow
check("new chat only greets (no auto-start)", "How can I help" in first[0]["text"]
      and not bot.current["state"]["active"])
check("greeting hides technical info", "Decision Tree" not in first[0]["text"])
check("help explains abilities", "recommend" in ask("how can you help you").lower())
out = ask("ok")
check("'ok' after help starts the questions", "Step 1 of 7" in out and "Nitrogen" in out)
check("hello mid-way is answered", "How can I help" in ask("hello"))
check("junk text during questions gets guidance", "number" in ask("blah blah").lower())
r1, r2 = ask("asdf qwer"), ask("zzz yyy")
check("replies are not identical repeats", r1 != r2)
check("asks what nitrogen is", "soil test" in ask("what is nitrogen"))
check("answer moves to step 2", "Step 2 of 7" in ask("90"))
out = ask("i don't know")
check("don't know -> offers typical value", "typical value" in out)
out = ask("yes")
check("yes uses typical value and moves on", "Step 3 of 7" in out and "typical value" in out)
check("hinglish don't know", "typical value" in ask("nahi pata"))
check("number after offer accepted", "Step 4 of 7" in ask("40"))
check("question mid-flow answered + returns", "Wheat" in ask("tell me about wheat")
      and "Step 4 of 7" in ask("hmm what is this").replace("Whenever you're ready, ", ""))
check("temperature accepted", "Step 5 of 7" in ask("26"))
check("invalid humidity rejected", "between 0 and 100" in ask("150"))
check("valid humidity accepted", "Step 6 of 7" in ask("60"))
ask("cancel")

# ---- one-line prediction, explanations
check("start works", "Step 1 of 7" in ask("lets start"))
out = ask("N=90 P=42 K=40 temp=26 humidity=82 ph=6.1 rainfall=210")
check("one-line prediction gives RICE", "rice" in out.lower())
check("result hides Decision Tree", "Decision Tree" not in out)
check("why uses last prediction", "RICE" in ask("why?"))
check("alternatives", "Best crops" in ask("show alternatives"))
check("invalid value rejected", "between" in (ask("start") and ask("N=500")))
ask("cancel")

# ---- memory
ask("show alternatives")
check("last topic", "Alternative" in ask("what was the last topic"))
check("last question", "show alternatives" in ask("what was my last question"))
ask("how are you")
check("small talk not counted as topic", "Alternative" in ask("what did we discuss"))

# ---- technical questions still answered ON REQUEST
check("model on request", "Decision Tree" in ask("which model do you use?"))
check("accuracy on request", "accuracy" in ask("accuracy kitni hai").lower())

# ---- saved chats
bot.new_chat()
check("previous chat remembered", "previous chat" in ask("what did we discuss last time").lower())
check("history file saved", os.path.exists(HIST))
check("chats reload from disk", len(ce.AgriBot(history_file=HIST).recent_chats()) >= 2)
for _ in range(8):
    bot.new_chat()
    bot.handle("tell me about rice")
check("only 5 chats kept", len(bot.chats) == 5)
bot.new_chat()
check("unknown text handled", "AgriBot" in ask("qwertyuiop zxcv") or "couldn't" in ask("qwertyuiop zxcv"))
print("\nAll tests passed.")

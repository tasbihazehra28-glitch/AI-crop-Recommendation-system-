"""
chatbot_engine.py
-----------------
The "brain" of AgriBot (no GUI code in here, so it can be tested on its own).

What it does
  * Understands what the user asks (keyword + typo-tolerant intent matching,
    English and simple Hinglish) and answers ONLY what was asked.
  * Collects the 7 soil/climate values and predicts a crop with the
    Decision Tree (values can be typed one by one, or all at once).
  * Remembers the topic of every message, so it can answer
    "what was the last topic we discussed?".
  * Saves the 5 most recent chats to chat_history.json, so they are still
    there after the program is closed and opened again.
"""

import difflib
import json
import os
import re
import tempfile
import time
import uuid
from datetime import datetime

from sklearn.metrics import precision_recall_fscore_support

import model_utils as mu

HISTORY_FILE = os.path.join(mu.BASE_DIR, "chat_history.json")
MAX_CHATS = 5

NUMBER = re.compile(r"-?\d+(?:\.\d+)?")

# ---------------------------------------------------------------------------
# Static knowledge
# ---------------------------------------------------------------------------

CROP_ALIASES = {
    "rice": "rice", "chawal": "rice", "paddy": "rice", "basmati": "rice",
    "wheat": "wheat", "gandum": "wheat", "gehun": "wheat",
    "maize": "maize", "corn": "maize", "makai": "maize",
    "cotton": "cotton", "kapas": "cotton",
    "sugarcane": "sugarcane", "ganna": "sugarcane", "sugar": "sugarcane",
    "chickpea": "chickpea", "chickpeas": "chickpea", "chana": "chickpea",
    "gram": "chickpea",
    "lentil": "lentil", "lentils": "lentil", "masoor": "lentil",
    "potato": "potato", "potatoes": "potato", "aloo": "potato",
    "tomato": "tomato", "tomatoes": "tomato", "tamatar": "tomato",
    "groundnut": "groundnut", "peanut": "groundnut", "peanuts": "groundnut",
    "mungfali": "groundnut",
}

CROP_NOTES = {
    "rice": "a Kharif (summer) crop that loves warm, wet and humid conditions.",
    "wheat": "a Rabi (winter) cereal that prefers cooler weather and moderate rain.",
    "maize": "a versatile cereal, usually grown in spring or the Kharif season.",
    "cotton": "a Kharif cash crop that needs high nitrogen, heat and little humidity.",
    "sugarcane": "a long-duration crop that needs a lot of water and warmth.",
    "chickpea": "a Rabi pulse that grows well in dry, cool conditions with less rain.",
    "lentil": "a Rabi pulse that prefers cool temperatures and low rainfall.",
    "potato": "a cool-season crop (autumn/winter planting) that needs moist soil.",
    "tomato": "a warm-season vegetable that needs steady moisture and mild heat.",
    "groundnut": "a Kharif oilseed/legume that prefers light soil and moderate rain.",
}

FEATURE_TEXT = {
    "N": "Nitrogen (N) drives leafy, vegetative growth. Cereals and cotton usually need "
         "more of it, pulses such as chickpea and lentil need less. Unit: kg/ha.",
    "P": "Phosphorus (P) supports root development and flowering. Unit: kg/ha.",
    "K": "Potassium (K) improves water regulation, disease resistance and crop quality. "
         "Unit: kg/ha.",
    "temperature": "Temperature (in °C) decides which season a crop suits - for example "
                   "wheat likes cool weather while rice and cotton like heat.",
    "humidity": "Humidity (%) is the moisture in the air. Rice and sugarcane like high "
                "humidity, chickpea and lentil like it low.",
    "ph": "Soil pH measures acidity (0-14). Most crops grow best between 6 and 7.5.",
    "rainfall": "Rainfall (in mm) is the water available to the crop. Rice and sugarcane "
                "need much more than chickpea or lentil.",
}

FEATURE_WORDS = {
    "nitrogen": "N", "phosphorus": "P", "phosphorous": "P", "potassium": "K",
    "temperature": "temperature", "temp": "temperature",
    "humidity": "humidity", "ph": "ph", "rainfall": "rainfall", "rain": "rainfall",
}

UNIT_WORDS = {"kg", "ha", "kgha", "c", "mm", "ph", "percent", "degree", "degrees"}

FEATURE_HELP = {
    "N": "You can get it from a soil test report (your local agriculture office or soil lab can test it).",
    "P": "You can get it from a soil test report (your local agriculture office or soil lab can test it).",
    "K": "You can get it from a soil test report (your local agriculture office or soil lab can test it).",
    "temperature": "Use the average temperature of your area during the growing season (a weather app or the local weather office will tell you).",
    "humidity": "Use the average relative humidity of your area (any weather app shows it).",
    "ph": "You can measure it with a soil pH meter or test kit, or get it from a soil test report.",
    "rainfall": "Use the typical rainfall of your area in mm (from the local weather office or a weather website).",
}

AFFIRM_WORDS = {
    "yes", "yeah", "yep", "yup", "yess", "ok", "okay", "k", "sure", "haan", "han", "ha", "ji",
    "jee", "hnji", "theek", "thik", "acha", "accha", "alright", "right", "please", "chalo",
    "fine", "y", "kar", "karo", "do", "go", "ahead", "lets", "let's", "done", "bilkul", "hmm",
}
NEGATIVE_WORDS = {"no", "nope", "nahi", "nahin", "nai", "na", "nhi", "nah", "not", "now", "later"}
NEGATIVE_CORE = {"no", "nope", "nahi", "nahin", "nai", "na", "nhi", "nah"}

DONT_KNOW = [
    "don't know", "dont know", "do not know", "not sure", "no idea", "nahi pata", "nahin pata",
    "nhi pata", "pata nahi", "pata nhi", "pata nahin", "skip", "don't have", "dont have",
    "do not have", "i have no", "nahi hai", "nhi hai", "unknown", "not available",
    "mere pass nahi", "mujhe nahi", "idk", "can't find", "cant find", "don't remember",
    "dont remember", "not known", "no value", "unavailable", "i don't", "i dont",
]
USE_DEFAULT = ["use typical", "typical value", "use average", "average value", "use default",
               "default value", "use that", "use it", "typical", "average"]
HOW_TO_FIND = [
    "how to find", "how do i find", "how can i find", "how to know", "how do i know",
    "how to measure", "where to find", "where can i find", "kaise pata", "kaise nikale",
    "kahan se", "what is this", "what is it", "what does it mean", "what does this mean",
    "meaning", "kya hota hai", "kya hai ye", "kya hai yeh", "what do you mean",
]
OFFER_INTENTS = ("help", "identity", "features", "list_crops")

# ---------------------------------------------------------------------------
# Intents: (topic label shown in memory, [(phrase, weight), ...])
# Multi-word phrases are matched as substrings, single words by token
# (with typo tolerance). The highest score wins.
# ---------------------------------------------------------------------------

def _w(*phrases, weight=2):
    return [(p, weight) for p in phrases]


INTENTS = {
    "greeting": ("Greeting", _w(
        "hello", "hi", "hey", "salam", "assalamualaikum", "aoa", "good morning",
        "good evening", "good afternoon", "namaste")),
    "thanks": ("Thanks", _w("thanks", "thank", "thankyou", "shukriya", "shukria", "jazakallah")),
    "bye": ("Goodbye", _w("bye", "goodbye", "see you", "khuda hafiz", "allah hafiz")),
    "smalltalk": ("Small talk", _w("how are you", "how r you", "kaise ho", "kya haal",
                                   "whats up", "what's up", "how do you do", "kese ho")),
    "compliment": ("Small talk", _w("nice", "great", "awesome", "wow", "well done", "cool",
                                    "perfect", "good job", "amazing", "wah", "excellent")),
    "help": ("What AgriBot can do", _w(
        "help", "what can you do", "kya kar sakty", "kya kar sakte", "capabilities",
        "options", "menu", "commands", "madad", "how can you help", "how can i use",
        "what can i ask", "how can you assist", "what do you offer", "kaise help")),
    "identity": ("About AgriBot", _w(
        "who are you", "your name", "introduce", "about you", "what are you",
        "tum kon", "aap kaun", "purpose", "your purpose", "your goal", "objective",
        "what do you do", "why were you made")),
    "start_prediction": ("Crop prediction", _w(
        "predict", "prediction", "start", "begin", "new prediction",
        "another prediction", "next prediction", "dobara", "phir se", "fasal batao",
        "crop batao", "mujhe fasal", "pehli prediction", "first prediction",
        "how to predict", "how do i predict", "how can i predict", "prediction kaise",
        "recommend a crop", "recommend me", "recommend crop", "suggest a crop",
        "suggest crop", "suggest me", "can you recommend", "please recommend",
        "which crop should", "best crop for", "which crop to grow", "crop recommendation",
        "i want a crop", "i want crop", "i need a crop", "i need crop", "i want recommendation",
        "i need recommendation", "want a recommendation", "need a recommendation",
        "recommendation chahiye", "crop chahiye", "fasal chahiye", "shuru", "chalo shuru",
        "lets start", "let's start", "go ahead", "recommend karo", "suggest karo") +
        _w("recommend", "recommendation", "suggest", weight=1)),
    "cancel": ("Cancelled prediction", _w(
        "cancel", "abort", "stop prediction", "stop", "quit", "reset", "restart",
        "start over", "nevermind", "never mind", "band karo")),
    "model": ("Algorithm used", _w(
        "which model", "what model", "which algorithm", "what algorithm", "algorithm",
        "model konsa", "model kaunsa", "classifier", "machine learning", "ml model",
        "criterion", "entropy", "max depth", "hyperparameter", "hyperparameters",
        "parameters of the model")),
    "decision_tree": ("What is a Decision Tree", _w(
        "decision tree", "decisiontree", "what is tree", "tree kya", "tree algorithm")),
    "how_works": ("How AgriBot works", _w(
        "how do you work", "how it works", "how does it work", "how does this work",
        "kaise kaam", "work kaise", "working", "how are you built", "workflow",
        "how you predict")),
    "features": ("Input features", _w(
        "features", "inputs", "input values", "which values", "what values", "kya kya",
        "what do you need", "what do you ask", "variables", "which parameters",
        "what parameters", "input parameters", "input data")),
    "feature_detail": ("Feature explanation", _w(
        "mean", "meaning", "explain", "what is", "what's", "role", "importance of",
        "kya hota", "kya hai", "define", "unit", "units", "how to find", "how do i find",
        "how to measure", "where to find", "kaise pata", "how to know", weight=1)),
    "importance": ("Feature importance", _w(
        "most important", "important feature", "important features", "feature importance",
        "which feature", "matters most", "most influential", "important parameter")),
    "accuracy": ("Model accuracy", _w(
        "accuracy", "accurate", "precision", "recall", "f1", "performance", "how good",
        "how reliable", "reliable", "kitni accuracy", "score", "evaluation", "metrics")),
    "why": ("Explanation of recommendation", _w(
        "why", "reason", "kyun", "kyu", "explain prediction", "explain result",
        "explain the result", "how did you decide", "how did you choose",
        "justify", "explain recommendation", "explain this")),
    "alternatives": ("Alternative crops / confidence", _w(
        "alternative", "alternatives", "other options", "other crop", "other crops",
        "second best", "top 3", "top three", "confidence", "how sure", "probability",
        "runner up", "next best")),
    "dataset": ("Dataset information", _w(
        "dataset", "data set", "data", "records", "samples", "rows", "csv", "training data",
        "synthetic", "how many crops", "train test", "split")),
    "list_crops": ("List of crops", _w(
        "which crops", "what crops", "list of crops", "list crops", "crops list",
        "supported crops", "all crops", "kaun si fasal", "konsi fasal", "crops can you")),
    "limitations": ("Limitations / improvements", _w(
        "limitation", "limitations", "weakness", "weaknesses", "drawback", "drawbacks",
        "improve", "improvement", "improvements", "future", "future work", "disadvantage",
        "problem with", "overfit", "overfitting")),
    "repeat": ("Repeat", _w("repeat", "say again", "once more", "dobara batao", "phir batao")),
}

# Priority when scores tie (earlier = preferred).
INTENT_ORDER = list(INTENTS.keys())

MEMORY_LAST_TOPIC = [
    "last topic", "previous topic", "earlier topic", "topic before", "pichla topic",
    "aakhri topic", "topic kya tha", "last discuss", "discussed before",
    "discussed earlier", "what did we discuss", "what we discussed",
    "what did we talk", "what were we talking", "what we talked", "kya discuss",
    "kya baat", "what have we discussed", "what have we talked",
    "what was the topic", "which topic", "pichli baat",
]
MEMORY_LAST_QUESTION = [
    "last question", "previous question", "what did i ask", "what i asked",
    "my last message", "maine kya pucha", "maine kya poocha", "my previous message",
]
MEMORY_CHAT_REF = [
    "previous chat", "last chat", "earlier chat", "old chat", "pichli chat",
    "pichle chat", "past chat", "past chats", "chat history", "recent chats",
    "all chats", "other chats", "my chats", "saved chats", "earlier conversation",
    "previous conversation", "last conversation", "history",
]

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _now():
    return datetime.now().isoformat(timespec="seconds")


def _normalise(text):
    text = text.lower().replace("’", "'")
    return re.sub(r"[^a-z0-9.'+\-=:\s%°]", " ", text)


def _tokens(text):
    return re.findall(r"[a-z0-9']+", text)


def _contains_phrase(text, phrase):
    return re.search(r"(?<![a-z0-9])" + re.escape(phrase) + r"(?![a-z0-9])", text) is not None


def _fuzzy_hit(token, word):
    """Typo tolerance for words with 6+ letters (e.g. 'accuracey', 'predicton')."""
    if len(word) < 6 or len(token) < 5:
        return False
    return difflib.SequenceMatcher(None, token, word).ratio() >= 0.86


def _score(text, tokens, phrases):
    total = 0.0
    for phrase, weight in phrases:
        if " " in phrase:
            if _contains_phrase(text, phrase):
                total += weight * len(phrase.split())
        else:
            if phrase in tokens:
                total += weight
            elif any(_fuzzy_hit(t, phrase) for t in tokens):
                total += weight * 0.8
    return total


def find_crop(tokens):
    for t in tokens:
        if t in CROP_ALIASES:
            return CROP_ALIASES[t]
    for t in tokens:                       # typo tolerance, e.g. "sugarcan", "potatoe"
        if len(t) >= 5:
            match = difflib.get_close_matches(t, CROP_ALIASES.keys(), n=1, cutoff=0.86)
            if match:
                return CROP_ALIASES[match[0]]
    return None


def parse_key_values(text):
    """'N=90, P 42, ph is 6.5' -> {'N': 90.0, 'P': 42.0, 'ph': 6.5}"""
    pattern = (r"(?<![a-z])(nitrogen|phosphorus|phosphorous|potassium|temperature|temp|"
               r"humidity|rainfall|rain|ph|n|p|k)\s*(?:is|=|:|-|of)?\s*(-?\d+(?:\.\d+)?)")
    found = {}
    for key, value in re.findall(pattern, text):
        feature = FEATURE_WORDS.get(key, key.upper() if key in ("n", "p", "k") else key)
        found[feature] = float(value)
    return found


def _is_numeric_message(text):
    """True for '90', '90 kg/ha', '26 c', '6.5', '90, 42, 40 ...' (numbers + units only)."""
    if not NUMBER.search(text):
        return False
    words = re.findall(r"[a-z]+", NUMBER.sub(" ", text.replace("°", "")))
    return all(w in UNIT_WORDS for w in words)


def _pct(x):
    return f"{x * 100:.0f}%"


# ---------------------------------------------------------------------------
# The chatbot
# ---------------------------------------------------------------------------

class AgriBot:
    def __init__(self, history_file=HISTORY_FILE, trained=None):
        self.history_file = history_file
        trained = trained or mu.train()
        self.model = trained["model"]
        self.accuracy = trained["accuracy"]
        self.profiles = trained["crop_profiles"]
        self.n_train = len(trained["X_train"])
        self.n_test = len(trained["X_test"])
        self.n_records = len(trained["data"])
        self.crops = sorted(self.profiles.keys())
        data = trained["data"]
        self.ranges = {f: (float(data[f].quantile(0.05)), float(data[f].quantile(0.95)))
                       for f in mu.FEATURES}
        self.means = {f: round(float(data[f].mean()), 1) for f in mu.FEATURES}

        pred = self.model.predict(trained["X_test"])
        p, r, f, _ = precision_recall_fscore_support(
            trained["y_test"], pred, average="macro", zero_division=0)
        self.precision, self.recall, self.f1 = p, r, f

        self.chats = []
        self.current = None
        self._load()

    # ------------------------------------------------------------------ storage
    def _load(self):
        try:
            with open(self.history_file, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            chats = data.get("chats", [])
            if isinstance(chats, list):
                self.chats = [c for c in chats if isinstance(c, dict) and "messages" in c][:MAX_CHATS]
        except (OSError, ValueError):
            self.chats = []

    def _save(self):
        self.chats.sort(key=lambda c: c.get("updated", ""), reverse=True)
        # Keep only the 5 most recent chats (never drop the open one).
        while len(self.chats) > MAX_CHATS:
            victim = next(c for c in reversed(self.chats) if c is not self.current)
            self.chats.remove(victim)
        try:
            folder = os.path.dirname(self.history_file) or "."
            fd, tmp = tempfile.mkstemp(dir=folder, suffix=".tmp")
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump({"version": 1, "chats": self.chats}, fh, indent=2, ensure_ascii=False)
            os.replace(tmp, self.history_file)
        except OSError:
            pass  # saving must never crash the chatbot

    # -------------------------------------------------------------- chat control
    def recent_chats(self):
        return sorted(self.chats, key=lambda c: c.get("updated", ""), reverse=True)

    def chat_label(self, chat):
        when = datetime.fromisoformat(chat["created"]).strftime("%d %b, %H:%M")
        return f"{chat['title']}  ·  {when}"

    @staticmethod
    def _has_user_message(chat):
        return any(m["sender"] == "user" for m in chat["messages"])

    def new_chat(self):
        """Start a chat (re-uses an empty one so greeting-only chats don't use up slots)."""
        if self.current is not None and not self._has_user_message(self.current):
            chat = self.current
            chat["messages"] = []
        else:
            chat = {
                "id": uuid.uuid4().hex,
                "title": "New chat",
                "created": _now(),
                "updated": _now(),
                "messages": [],
                "topics": [],
                "state": {"active": False, "step": 0, "values": {},
                          "last_values": None, "last_prediction": None, "topic_idx": None},
            }
            self.chats.insert(0, chat)
        self.current = chat
        self.current["state"].update({"active": False, "step": 0, "values": {},
                                      "offer_start": False, "offer_default": None,
                                      "topic_idx": None, "fallback_n": 0})
        replies = [self._bot("Hello! 👋 I'm AgriBot, your crop recommendation assistant.\n"
                             "How can I help you today?")]
        self._save()
        return replies

    def open_chat(self, chat_id):
        for chat in self.chats:
            if chat["id"] == chat_id:
                self.current = chat
                return chat["messages"]
        return []

    # ----------------------------------------------------------------- messages
    def _add(self, sender, text, extra=None):
        msg = {"sender": sender, "text": text, "time": _now()}
        if extra:
            msg["extra"] = extra
        self.current["messages"].append(msg)
        self.current["updated"] = _now()
        return msg

    def _bot(self, text):
        return self._add("bot", text)

    def _record_topic(self, topic, question):
        chat = self.current
        chat["topics"].append({"topic": topic, "question": question, "time": _now()})
        if chat["title"] == "New chat":
            chat["title"] = topic
        return len(chat["topics"]) - 1

    # ------------------------------------------------------------------- engine
    # ------------------------------------------------------------ question text
    def _question(self, feature):
        i = mu.FEATURES.index(feature) + 1
        name, unit = mu.FEATURE_INFO[feature]
        lo, hi = self.ranges[feature]
        fmt = (lambda x: f"{x:.1f}") if feature == "ph" else (lambda x: f"{x:.0f}")
        asks = {
            "N": "How much nitrogen is in your soil? Enter it in kg/ha",
            "P": "How much phosphorus is in your soil? Enter it in kg/ha",
            "K": "How much potassium is in your soil? Enter it in kg/ha",
            "temperature": "What is the average temperature of your area? Enter it in °C",
            "humidity": "What is the average humidity? Enter it as a percentage",
            "ph": "What is the pH of your soil? Enter a number between 0 and 14",
            "rainfall": "How much rainfall does your area get? Enter it in mm",
        }
        return (f"Step {i} of {len(mu.FEATURES)} - {name}\n{asks[feature]} "
                f"(usual range: {fmt(lo)} to {fmt(hi)}).\n"
                "Not sure? Just say \"I don't know\".")

    def _help_text(self, feature):
        return FEATURE_TEXT[feature] + "\nHow to find it: " + FEATURE_HELP[feature]

    @staticmethod
    def _is_affirm(toks):
        return 0 < len(toks) <= 4 and all(t in AFFIRM_WORDS for t in toks)

    @staticmethod
    def _is_negative(toks):
        return 0 < len(toks) <= 3 and all(t in NEGATIVE_WORDS for t in toks) \
            and any(t in NEGATIVE_CORE for t in toks)

    def _fallback(self, feature=None):
        state = self.current["state"]
        n = state.get("fallback_n", 0)
        state["fallback_n"] = n + 1
        if feature:
            name, unit = mu.FEATURE_INFO[feature]
            short = name.split(" (")[0].lower()
            example = f"{self.means[feature]:g}"
            options = [
                f"I didn't catch a number there. Please enter the {short}"
                f"{' in ' + unit if unit else ''}. (Say \"I don't know\" if you don't have it, "
                "or \"cancel\" to stop.)",
                f"Hmm, I need a number for the {short} to continue - for example {example}. "
                "You can also ask me a question, say \"I don't know\", or type \"cancel\".",
                f"Let's finish this step first - what is the {short}? Just type a number, "
                "or say \"skip\" if you're unsure.",
            ]
        else:
            options = [
                "I'm not sure I understood that. I'm AgriBot - I can recommend the best crop for "
                "your land or tell you about a crop. Say 'start' for a recommendation, or ask "
                "something like 'tell me about wheat'.",
                "Sorry, I couldn't get that. Could you say it a little differently? For example: "
                "'recommend a crop', 'what is nitrogen?' or 'what was the last topic?'.",
                "That's a bit outside what I know - I focus on crops and soil. Try 'start' to get "
                "a crop recommendation, or ask me about any of the 10 crops I know.",
            ]
        return [self._bot(options[n % len(options)])]

    def handle(self, text):
        """Process one user message. Returns the list of bot messages (dicts)."""
        text = (text or "").strip()
        if not text:
            return []
        self._add("user", text)
        try:
            replies = self._route(text)
        except Exception as exc:  # never let a bug kill the chat window
            replies = [self._bot(f"Sorry, something went wrong while processing that ({exc}). "
                                 "Please try again.")]
        self._save()
        return replies

    def _route(self, text):
        norm = _normalise(text)
        toks = _tokens(norm)
        state = self.current["state"]
        for key, default in (("offer_start", False), ("offer_default", None), ("fallback_n", 0)):
            state.setdefault(key, default)
        offer_start, offer_default = state["offer_start"], state["offer_default"]
        state["offer_start"] = False

        # 1. Memory questions ("what did we discuss...") work at any moment.
        memory = self._memory_intent(norm)
        if memory:
            return memory(norm)

        if state["active"]:
            feature = mu.FEATURES[state["step"]]
            # 2a. Answers to the pending question
            if any(_contains_phrase(norm, w) for w in ("cancel", "stop", "abort", "quit")):
                return self._cancel(text)
            kv = parse_key_values(norm)
            if kv:
                state["offer_default"] = None
                return self._accept_values(kv, text)
            if _is_numeric_message(norm):
                state["offer_default"] = None
                return self._accept_numbers(norm, text)
            if offer_default and (self._is_affirm(toks) or
                                  any(_contains_phrase(norm, p) for p in USE_DEFAULT)):
                return self._use_default(offer_default, text)
            if offer_default and self._is_negative(toks):
                state["offer_default"] = None
                return [self._bot("Okay, no problem.\n\n" + self._question(feature))]
            if self._is_negative(toks) or any(_contains_phrase(norm, p) for p in DONT_KNOW):
                return self._dont_know(feature)
            if any(_contains_phrase(norm, p) for p in HOW_TO_FIND) and not self._feature_in(toks):
                return [self._bot(self._help_text(feature)),
                        self._bot("Whenever you're ready, " + self._question(feature))]
        else:
            # 2b. Short "yes / ok / no" replies when nothing is pending
            if self._is_affirm(toks):
                if offer_start:
                    return self._begin_prediction(announce=True, question=text)
                state["offer_start"] = True
                return [self._bot("Great! Would you like me to recommend a crop for your land? "
                                  "Just say 'yes' or 'start' whenever you're ready.")]
            if self._is_negative(toks):
                return [self._bot("No problem! I'm here whenever you need me. You can ask me about "
                                  "any crop, or say 'start' for a crop recommendation.")]

        # 3. Ordinary intent matching.
        intent = self._detect_intent(norm, toks)
        if intent:
            return self._answer(intent, norm, toks, text)

        # 4. Nothing matched - answer in a way that fits the situation.
        if state["active"]:
            return self._fallback(mu.FEATURES[state["step"]])
        return self._fallback()

    def _detect_intent(self, norm, toks):
        crop = find_crop(toks)
        scores = {}
        for name in INTENT_ORDER:
            scores[name] = _score(norm, toks, INTENTS[name][1])

        # A feature word + a "what is..." word means a feature explanation.
        feature = self._feature_in(toks)
        if feature and (scores["feature_detail"] >= 1 or len(toks) <= 3):
            scores["feature_detail"] += 3
        elif feature:
            scores["feature_detail"] = 0
        else:
            scores["feature_detail"] = 0

        if crop:
            # a crop name asks for crop info unless the user clearly wants something else
            asks_info = re.search(r"about|tell|info|ideal|condition|grow|need|require|best|"
                                  r"suit|season|batao|details|describe", norm)
            scores["crop_info"] = 5 if asks_info else 3
            if any(scores[k] >= 2 for k in ("start_prediction", "why", "alternatives",
                                            "accuracy", "dataset", "list_crops")):
                scores["crop_info"] = 0

        best = max(scores, key=lambda k: (scores[k], -INTENT_ORDER.index(k) if k in INTENT_ORDER else -99))
        if scores[best] < 2:
            return None
        # Greetings are only greetings when the message is short ("hi", "hello there").
        if best == "greeting" and len(toks) > 4:
            others = {k: v for k, v in scores.items() if k != "greeting"}
            best2 = max(others, key=others.get)
            return best2 if others[best2] >= 2 else None
        return best

    @staticmethod
    def _feature_in(toks):
        for t in toks:
            if t in FEATURE_WORDS:
                return FEATURE_WORDS[t]
        for t in toks:
            if t in ("n", "p", "k"):
                return t.upper()
        return None

    # -------------------------------------------------------------------- memory
    def _memory_intent(self, norm):
        if any(_contains_phrase(norm, p) for p in MEMORY_CHAT_REF):
            return self._mem_chats
        if any(_contains_phrase(norm, p) for p in MEMORY_LAST_QUESTION):
            return self._mem_last_question
        if any(_contains_phrase(norm, p) for p in MEMORY_LAST_TOPIC):
            return self._mem_last_topic
        return None

    def _topics_text(self, topics, limit=6):
        shown = topics[-limit:]
        return "\n".join(f"  {i}. {t['topic']}" for i, t in enumerate(shown, 1))

    def _previous_chat(self):
        others = [c for c in self.recent_chats() if c is not self.current and c["topics"]]
        return others[0] if others else None

    def _mem_last_topic(self, norm):
        chat = self.current
        topics = chat["topics"]
        if topics:
            last = topics[-1]
            msg = f"The last topic we discussed was: {last['topic']}"
            msg += f"\n(You asked: \"{last['question']}\")"
            if len(topics) > 1:
                msg += f"\n\nBefore that: {topics[-2]['topic']}"
            if len(topics) > 2:
                msg += f"\nAll topics in this chat so far:\n{self._topics_text(topics)}"
            return [self._bot(msg)]
        prev = self._previous_chat()
        if prev:
            msg = ("We haven't discussed anything yet in this chat.\n\n"
                   f"In your previous chat ({self.chat_label(prev)}) the last topic was: "
                   f"{prev['topics'][-1]['topic']}")
            if len(prev["topics"]) > 1:
                msg += f"\nTopics covered there:\n{self._topics_text(prev['topics'])}"
            return [self._bot(msg)]
        return [self._bot("We haven't discussed any topic yet - this is our first conversation. "
                          "Ask me anything about crop recommendation!")]

    def _mem_last_question(self, norm):
        users = [m for m in self.current["messages"] if m["sender"] == "user"][:-1]
        # ignore pure-number answers and memory questions
        users = [m for m in users if not _is_numeric_message(_normalise(m["text"]))
                 and not self._memory_intent(_normalise(m["text"]))]
        if users:
            return [self._bot(f"Your previous question was: \"{users[-1]['text']}\"")]
        return [self._bot("You haven't asked me a question yet in this chat.")]

    def _mem_chats(self, norm):
        chats = self.recent_chats()
        wants_list = any(_contains_phrase(norm, p) for p in
                         ("history", "recent chats", "all chats", "my chats", "saved chats",
                          "past chats", "other chats"))
        if wants_list:
            lines = []
            for i, c in enumerate(chats, 1):
                marker = " (this chat)" if c is self.current else ""
                topics = ", ".join(t["topic"] for t in c["topics"][-3:]) or "no topics yet"
                lines.append(f"  {i}. {self.chat_label(c)}{marker}\n     Topics: {topics}")
            return [self._bot(f"Here are your {len(chats)} most recent chats (I keep the last "
                              f"{MAX_CHATS}):\n" + "\n".join(lines))]
        prev = self._previous_chat()
        if not prev:
            return [self._bot("I don't have an earlier chat saved yet. Once you start a new chat, "
                              "this one will be remembered.")]
        msg = (f"In your previous chat ({self.chat_label(prev)}) we discussed:\n"
               f"{self._topics_text(prev['topics'], 8)}")
        return [self._bot(msg)]

    # ------------------------------------------------------------------- answers
    def _answer(self, intent, norm, toks, original):
        if intent in ("start_prediction",):
            return self._begin_prediction(announce=True, question=original)
        if intent == "cancel":
            if re.search(r"restart|reset|start over", norm):
                return self._begin_prediction(announce=True, question=original)
            return self._cancel(original)

        topic = INTENTS[intent][0] if intent in INTENTS else "Crop information"
        handler = getattr(self, f"_a_{intent}")
        text = handler(norm, toks)
        if text is None:
            return []
        quiet = ("greeting", "thanks", "bye", "repeat", "smalltalk", "compliment")
        if intent not in quiet:
            self._record_topic(self._topic_label(intent, norm, toks, topic), original)
        state = self.current["state"]
        if intent in OFFER_INTENTS and not state["active"]:
            text += "\n\nWould you like me to recommend a crop for your land now? Just say 'yes' or 'start'."
            state["offer_start"] = True
        replies = [self._bot(text)]
        if state["active"] and intent not in quiet:
            feature = mu.FEATURES[state["step"]]
            replies.append(self._bot("Now, back to your recommendation.\n\n" + self._question(feature)))
        return replies

    def _topic_label(self, intent, norm, toks, topic):
        if intent == "crop_info":
            return f"Information about {find_crop(toks)}"
        if intent == "feature_detail":
            f = self._feature_in(toks)
            return f"Explanation of {mu.FEATURE_INFO[f][0]}" if f else topic
        return topic

    # -- simple conversational answers
    def _a_greeting(self, norm, toks):
        return "Hello! How can I help you with your crops today?"

    def _a_smalltalk(self, norm, toks):
        return "I'm doing great, thank you for asking! How can I help you with your crops today?"

    def _a_compliment(self, norm, toks):
        return "Thank you, I'm glad you like it! 🌱 Anything else I can help you with?"

    def _a_thanks(self, norm, toks):
        return "You're welcome! Let me know if you want another prediction or have more questions."

    def _a_bye(self, norm, toks):
        return "Goodbye! Your recent chats are saved, so you can come back to them anytime."

    def _a_help(self, norm, toks):
        return ("I can help you with:\n"
                "• Recommending the best crop for your soil and weather - just say 'start'\n"
                "• Explaining why I picked a crop ('why?') and showing other good options\n"
                "• Information about any crop, for example 'tell me about wheat'\n"
                "• Remembering our chats - 'what was the last topic?'")

    def _a_identity(self, norm, toks):
        return ("I'm AgriBot, a smart crop assistant. I suggest the most suitable crop for your "
                "land based on your soil nutrients (N, P, K), soil pH, temperature, humidity and "
                "rainfall, and I can explain my suggestion.")

    def _a_model(self, norm, toks):
        p = mu.BEST_PARAMS
        return (f"I use a Decision Tree Classifier (scikit-learn). Settings: criterion = "
                f"{p['criterion']}, max_depth = {p['max_depth']}, min_samples_split = "
                f"{p['min_samples_split']}, min_samples_leaf = {p['min_samples_leaf']}. "
                "These values were chosen with GridSearchCV (5-fold cross-validation) on the "
                "training data only.")

    def _a_decision_tree(self, norm, toks):
        return ("A Decision Tree is a supervised machine-learning algorithm that predicts by "
                "asking a chain of yes/no questions about the input, such as 'is rainfall > "
                "150 mm?'. Each question splits the data, and each leaf of the tree gives a "
                "crop. With the entropy criterion, every split is chosen to reduce "
                "uncertainty (information gain) as much as possible.")

    def _a_how_works(self, norm, toks):
        return ("1) You give me 7 soil/climate values.\n"
                "2) The trained Decision Tree follows its learned rules from the root to a leaf "
                "using your values.\n"
                "3) The leaf gives the recommended crop, and the share of training samples in "
                "that leaf gives the confidence.\n"
                "4) Ask 'why?' and I will show the rules that were followed.")

    def _a_features(self, norm, toks):
        lines = [f"• {name}" + (f" ({unit})" if unit else "")
                 for name, unit in mu.FEATURE_INFO.values()]
        return "I use these 7 input features:\n" + "\n".join(lines)

    def _a_feature_detail(self, norm, toks):
        f = self._feature_in(toks)
        return self._help_text(f) if f else None

    def _a_importance(self, norm, toks):
        imp = sorted(zip(mu.FEATURES, self.model.feature_importances_), key=lambda x: -x[1])
        lines = [f"  {i}. {mu.FEATURE_INFO[f][0]} - {v * 100:.1f}%"
                 for i, (f, v) in enumerate(imp, 1)]
        return ("Feature importance in my Decision Tree (how much each input helped the "
                "splits):\n" + "\n".join(lines))

    def _a_accuracy(self, norm, toks):
        return (f"On the unseen 20% test set ({self.n_test} records) the Decision Tree "
                f"scored: accuracy {self.accuracy * 100:.2f}%, precision {self.precision * 100:.2f}%, "
                f"recall {self.recall * 100:.2f}% and F1-score {self.f1 * 100:.2f}% (macro average).\n"
                "The accuracy is moderate because the dataset is synthetic and several crops "
                "overlap in their soil/climate values. Treat the output as decision support, "
                "not a guarantee.")

    def _a_dataset(self, norm, toks):
        return (f"The dataset has {self.n_records} records, 7 input features and 10 crops "
                f"({', '.join(self.crops)}), with 100 records per crop. It is split 80% / 20% "
                f"into {self.n_train} training and {self.n_test} testing records (stratified). "
                "It is a synthetic, educational dataset; a real deployment needs verified "
                "regional field data.")

    def _a_list_crops(self, norm, toks):
        return ("I can recommend these 10 crops:\n" +
                ", ".join(c.title() for c in self.crops) +
                ".\nAsk 'tell me about <crop>' for its typical conditions.")

    def _a_limitations(self, norm, toks):
        return ("Limitations:\n"
                "• The dataset is synthetic, and crops overlap, so accuracy is limited.\n"
                "• A single Decision Tree can overfit.\n"
                "• Real decisions also depend on market price, seeds, irrigation, pests and location.\n"
                "Possible improvements: use verified Pakistan/regional data, compare with Random "
                "Forest, add weather forecasts and crop prices.")

    def _a_repeat(self, norm, toks):
        bots = [m for m in self.current["messages"] if m["sender"] == "bot"]
        return bots[-1]["text"] if bots else "I haven't said anything yet."

    def _a_crop_info(self, norm, toks):
        crop = find_crop(toks)
        prof = self.profiles[crop]
        rows = []
        for f in mu.FEATURES:
            lo, hi, _ = prof[f]
            name, unit = mu.FEATURE_INFO[f]
            rows.append(f"• {name}: {lo:.1f} - {hi:.1f} {unit}".rstrip())
        return (f"{crop.title()} is {CROP_NOTES[crop]}\n"
                f"Typical conditions for {crop} in my dataset (10th-90th percentile):\n" +
                "\n".join(rows))

    # ---- explanation of the last prediction
    def _a_why(self, norm, toks):
        state = self.current["state"]
        if not state["last_prediction"]:
            return "I haven't made a recommendation in this chat yet. Say 'start' and I'll find a crop for you."
        crop, values = state["last_prediction"], state["last_values"]
        prof = self.profiles[crop]
        inside, outside = [], []
        for f in mu.FEATURES:
            lo, hi, _ = prof[f]
            short = mu.FEATURE_INFO[f][0].split(" (")[0].lower()
            (inside if lo <= values[f] <= hi else outside).append(short)
        text = f"I recommended {crop.upper()} because your conditions match what {crop} usually needs.\n"
        if inside:
            text += f"• Good match: {', '.join(inside)}\n"
        if outside:
            text += f"• Less typical for {crop}: {', '.join(outside)}\n"
        text += "Please also check with a local agriculture expert before you decide."
        return text

    def _a_alternatives(self, norm, toks):
        state = self.current["state"]
        if not state["last_prediction"]:
            return "I haven't made a recommendation in this chat yet. Say 'start' and I'll find a crop for you."
        top = mu.predict_top(self.model, state["last_values"], k=3)
        lines = [f"  {i}. {c.title()} - {_pct(p)}" for i, (c, p) in enumerate(top, 1)]
        return ("Best crops for your conditions:\n" + "\n".join(lines) +
                "\n(The percentage shows how closely your conditions match each crop.)")

    def _begin_prediction(self, announce, question=None):
        state = self.current["state"]
        state.update({"active": True, "step": 0, "values": {}, "topic_idx": None,
                      "offer_default": None})
        replies = []
        if announce:
            state["topic_idx"] = self._record_topic("Crop prediction (in progress)", question or "start")
            replies.append(self._bot(
                "Great, let's find the best crop for your land! 🌾 I'll ask you 7 quick questions "
                "about your soil and weather, one at a time.\n"
                "Tip: you can also type everything in one line, like:\n"
                "N=90 P=42 K=40 temp=26 humidity=82 ph=6.1 rainfall=210\n"
                "You can ask me a question at any time, or type 'cancel' to stop."))
        replies.append(self._bot(self._question("N")))
        return replies

    def _cancel(self, original):
        state = self.current["state"]
        if not state["active"]:
            return [self._bot("There is no recommendation in progress. Say 'start' to begin one.")]
        if state["topic_idx"] is not None and state["topic_idx"] < len(self.current["topics"]):
            self.current["topics"][state["topic_idx"]]["topic"] = "Crop prediction (cancelled)"
        state.update({"active": False, "step": 0, "values": {}, "topic_idx": None,
                      "offer_default": None})
        return [self._bot("Okay, I've stopped the recommendation. Say 'start' whenever you want to try again.")]

    def _validate(self, feature, value):
        lo, hi = mu.FEATURE_LIMITS[feature]
        if lo <= value <= hi:
            return None
        name, unit = mu.FEATURE_INFO[feature]
        return (f"⚠ {name} must be between {lo} and {hi} {unit}".rstrip() +
                ". Please enter a valid value.")

    def _ensure_topic(self, original):
        state = self.current["state"]
        if state["topic_idx"] is None:
            state["topic_idx"] = self._record_topic("Crop prediction (in progress)", original)

    @staticmethod
    def _fmt_value(feature, value):
        name, unit = mu.FEATURE_INFO[feature]
        return f"{name.split(' (')[0]} = {value:g}" + (f" {unit}" if unit else "")

    def _first_missing(self):
        values = self.current["state"]["values"]
        return next((i for i, f in enumerate(mu.FEATURES) if f not in values), len(mu.FEATURES))

    def _store(self, targets):
        state = self.current["state"]
        accepted, errors = [], []
        for feature, value in targets:
            err = self._validate(feature, value)
            if err:
                errors.append(err)
            else:
                state["values"][feature] = value
                accepted.append(self._fmt_value(feature, value))
        state["step"] = self._first_missing()
        return accepted, errors

    def _prefix(self, accepted, errors):
        lines = list(errors)
        if accepted:
            lines.append("✔ Got it: " + ", ".join(accepted))
        return "\n".join(lines)

    def _accept_values(self, kv, original):
        self._ensure_topic(original)
        accepted, errors = self._store(list(kv.items()))
        return self._next_or_finish(self._prefix(accepted, errors))

    def _accept_numbers(self, norm, original):
        state = self.current["state"]
        self._ensure_topic(original)
        numbers = [float(n) for n in NUMBER.findall(norm)]
        remaining = [f for f in mu.FEATURES if f not in state["values"]]
        if len(numbers) > 1 and len(numbers) == len(remaining):
            targets = list(zip(remaining, numbers))
        elif len(numbers) == 1:
            targets = [(mu.FEATURES[state["step"]], numbers[0])]
        else:
            return [self._bot(f"Please send one number at a time, or all {len(remaining)} remaining "
                              f"values in order ({', '.join(remaining)}).")]
        accepted, errors = [], []
        for target in targets:
            a, e = self._store([target])
            accepted += a
            errors += e
            if e:
                break
        return self._next_or_finish(self._prefix(accepted, errors))

    def _dont_know(self, feature):
        state = self.current["state"]
        state["offer_default"] = feature
        name, unit = mu.FEATURE_INFO[feature]
        short = name.split(" (")[0].lower()
        value = self.means[feature]
        return [self._bot(
            f"No problem! {FEATURE_HELP[feature]}\n"
            f"If you can't get it right now, I can use a typical value for {short} "
            f"({value:g}{' ' + unit if unit else ''}) so we can continue. "
            "Reply 'yes' to use it, or type your own value.")]

    def _use_default(self, feature, original):
        state = self.current["state"]
        self._ensure_topic(original)
        value = self.means[feature]
        state["values"][feature] = value
        state["offer_default"] = None
        state["step"] = self._first_missing()
        note = (f"Okay, I'll use the typical value for {self._fmt_value(feature, value)}. "
                "(The result may be a little less accurate for your land.)")
        return self._next_or_finish(note)

    def _next_or_finish(self, prefix=""):
        state = self.current["state"]
        if state["step"] < len(mu.FEATURES):
            question = self._question(mu.FEATURES[state["step"]])
            return [self._bot((prefix + "\n\n" if prefix else "") + question)]
        return self._finish_prediction(prefix)

    def _finish_prediction(self, prefix=""):
        state = self.current["state"]
        values = dict(state["values"])
        top = mu.predict_top(self.model, values, k=3)
        crop, conf = top[0]
        state.update({"active": False, "step": 0, "last_values": values,
                      "last_prediction": crop, "values": {}, "offer_default": None})
        topics = self.current["topics"]
        idx = state.get("topic_idx")
        if idx is not None and idx < len(topics):
            entry = topics.pop(idx)
        else:
            entry = {"question": "crop recommendation", "time": _now()}
        entry["topic"] = f"Crop prediction (recommended: {crop.upper()})"
        topics.append(entry)
        state["topic_idx"] = None
        self.current["title"] = "Crop recommendation"

        lead = self._bot((prefix + "\n\n" if prefix else "") +
                         "Thank you! I have all 7 values. Here is my recommendation:")
        extra = {"confidence": conf, "alternatives": [[c, p] for c, p in top[1:]]}
        self._add("card", crop, extra)
        follow = self._bot("Ask 'why?' to see why I chose it, 'show alternatives' for other good "
                           "crops, or say 'start' for another recommendation. Please also confirm "
                           "with a local agriculture expert before you plant.")
        return [lead, {"sender": "card", "text": crop, "extra": extra}, follow]
